package com.vera.chat

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.JavascriptInterface
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread
import android.view.WindowManager

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null
    private val fileChooserRequestCode = 4104
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(6, 11, 9)
        window.navigationBarColor = android.graphics.Color.rgb(6, 11, 9)
        window.decorView.systemUiVisibility = 0
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        web = WebView(this)
        web.setBackgroundColor(android.graphics.Color.rgb(6, 11, 9))
        val s: WebSettings = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.allowFileAccess = false
        s.allowContentAccess = true
        s.loadsImagesAutomatically = true
        s.cacheMode = WebSettings.LOAD_DEFAULT
        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: WebChromeClient.FileChooserParams?
            ): Boolean {
                fileChooserCallback?.onReceiveValue(null)
                fileChooserCallback = filePathCallback
                return try {
                    val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                    }
                    startActivityForResult(intent, fileChooserRequestCode)
                    true
                } catch (_: Exception) {
                    fileChooserCallback?.onReceiveValue(null)
                    fileChooserCallback = null
                    false
                }
            }
        }
        web.addJavascriptInterface(NativeApi(), "VeraNative")
        setContentView(web)
        if (savedInstanceState == null) web.loadUrl("file:///android_asset/index.html") else web.restoreState(savedInstanceState)
    }
    inner class NativeApi {
        @JavascriptInterface fun request(id: String, url: String, headersJson: String, body: String) {
            thread {
                var status = 0
                var response = "{}"
                try {
                    val conn = (URL(url).openConnection() as HttpURLConnection)
                    conn.requestMethod = "POST"
                    conn.connectTimeout = 25000
                    conn.readTimeout = 60000
                    conn.doOutput = true
                    val headers = JSONObject(headersJson)
                    val keys = headers.keys()
                    while (keys.hasNext()) { val k = keys.next(); conn.setRequestProperty(k, headers.getString(k)) }
                    conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                    status = conn.responseCode
                    val stream = if (status in 200..299) conn.inputStream else conn.errorStream
                    response = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: "{}"
                    conn.disconnect()
                } catch (e: Exception) {
                    response = JSONObject().put("error", JSONObject().put("message", e.message ?: "Network error")).toString()
                }
                val safe = JSONObject.quote(response)
                runOnUiThread { web.evaluateJavascript("window.onVeraNativeResult && window.onVeraNativeResult(${JSONObject.quote(id)}, $status, $safe)", null) }
            }
        }
    }
    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == fileChooserRequestCode) {
            val callback = fileChooserCallback ?: return
            val results = if (resultCode == RESULT_OK) WebChromeClient.FileChooserParams.parseResult(resultCode, data) else null
            callback.onReceiveValue(results)
            fileChooserCallback = null
        }
    }

    override fun onSaveInstanceState(outState: Bundle) { web.saveState(outState); super.onSaveInstanceState(outState) }
    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        // evaluateJavascript is asynchronous and returns Unit; inspect its callback result instead.
        web.evaluateJavascript("document.body.classList.contains('panel-open')") { result ->
            if (result == "true") {
                web.evaluateJavascript("closeOverlays()", null)
            } else if (web.canGoBack()) {
                web.goBack()
            } else {
                web.evaluateJavascript("closeOverlays()", null)
            }
        }
    }
    override fun onDestroy() { fileChooserCallback?.onReceiveValue(null); fileChooserCallback = null; web.destroy(); super.onDestroy() }
}
