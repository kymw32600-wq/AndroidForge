#!/usr/bin/env python3
"""VERA Web — local browser UI for the VERA 3.5 local core."""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from urllib.parse import urlparse
from pathlib import Path
import json, os, re, sys
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

ROOT = Path(__file__).resolve().parent
STATIC = ROOT / "static"
PORT = int(os.environ.get("VERA_PORT", "8765"))

# Import the existing VERA memory/planning/knowledge core without launching its CLI.
sys.path.insert(0, str(ROOT))
import vera_core as core

SYSTEM_BASE = """أنت VERA، مساعد ذكي ودود يتكلم بطبيعية كصديق محترم، خفيف دم من غير مبالغة. أنت ذكاء اصطناعي ولست إنسانًا، فلا تدّعِ أنك شخص حقيقي أو أنك تتصل هاتفيًا فعلًا. استخدم إيموجي عند ملاءمته للتفاعل (مثل 😂 عند المزاح)، ولا تكثر منها. كن صادقًا: لا تخترع معلومات أو مصادر، وقل بوضوح عندما لا تعرف أو تحتاج تحققًا. التزم باللهجة التي يختارها المستخدم في الواجهة أو يطلبها بالكلام، واستمر عليها حتى يطلب تغييرها؛ لا تفرض لهجة من نفسك. افهم المقصود من سياق المحادثة، واسأل سؤال توضيح واحدًا إذا كان المقصود ملتبسًا، ولا تخلط بين اسم محافظة واسم مرض أو بين أماكن متشابهة. إذا سأل عن محافظة المنوفية في مصر، فهي محافظة في دلتا النيل وعاصمتها شبين الكوم؛ لا تفسرها على أنها مرض. لا تدّعِ معرفة طقس لحظي أو أحداث حديثة من دون أداة تحقق مباشرة؛ وضّح حدودك واطلب المدينة إذا لزم. إذا طلب المستخدم نصًا طويلًا أو دينيًا، لا تدّعِ أنه كامل ولا تخترع تكملة؛ إن لم تستطع ضمان النص الكامل، قل ذلك بوضوح واقترح تقسيمه إلى أجزاء موثوقة بدل عرض نص ناقص على أنه كامل. لا تختلق معلومات، تعريفات، مصادر، أو إجابات لمجرد ملء الفراغ. عند عدم اليقين، صرّح به باختصار. لا تحفظ ردود النموذج كحقائق في الذاكرة تلقائيًا. لا تكشف مفتاح API أبدًا. اجعل الرد على قد السؤال، وابتعد عن الحشو والخلط بين اللغات إلا لو المستخدم طلب ذلك."""

# Keep deterministic VERA commands on the local core; send ordinary conversation/questions to the AI.
LOCAL_ONLY_CATEGORIES = {
    'safe_project_agent', 'local_core_status', 'local_evidence', 'system_report',
    'system_health', 'learning', 'knowledge', 'reasoning', 'memory', 'planning',
    'calculator', 'time', 'date', 'files', 'profile', 'about', 'help', 'ai_status'
}


def json_response(handler, data, status=200):
    raw = json.dumps(data, ensure_ascii=False).encode('utf-8')
    handler.send_response(status)
    handler.send_header('Content-Type', 'application/json; charset=utf-8')
    handler.send_header('Content-Length', str(len(raw)))
    handler.send_header('Cache-Control', 'no-store')
    handler.end_headers()
    handler.wfile.write(raw)


def clean_name_from_message(text):
    s = str(text).strip()
    patterns = [
        r"(?i)^\s*my name is\s+(.+?)\s*[.!؟?]*$",
        r"(?i)^\s*i am\s+(.+?)\s*[.!؟?]*$",
        r"^\s*(?:اسمي|انا اسمي|أنا اسمي|ناديني)\s+(.+?)\s*[.!؟?]*$",
    ]
    for p in patterns:
        m = re.match(p, s)
        if m:
            name = m.group(1).strip().strip(' .!؟?،,')
            if 1 <= len(name) <= 60:
                return name
    return None


def asks_name(text):
    n = core.normalize_text(text)
    patterns = ["what is my name", "whats my name", "do you know my name", "ايه اسمي", "اسمي ايه", "انا اسمي ايه", "فاكر اسمي", "عارف اسمي", "ما اسمي"]
    return any(core.normalize_text(p) == n for p in patterns)


def asks_remember(text):
    n = core.normalize_text(text)
    return any(x in n for x in ["remember that", "remember this", "افتكر ان", "افتكر إن", "احفظ ان", "احفظ إن", "خلي بالك ان", "خلي بالك إن"])


def local_reply(user_text):
    """Deterministic profile handling prevents the name-memory bug from falling through to AI."""
    name = clean_name_from_message(user_text)
    if name:
        core.add_memory("profile", name, source="web_chat")
        return f"تمام، حفظت اسمك {name} في ذاكرتي المحلية 💚", "memory_profile"
    if asks_name(user_text):
        name = core.get_name()
        if name:
            return f"اسمك {name} 😄", "memory_profile"
        return "لسه ماعرفش اسمك. قولّي: اسمي Kimo، وهحفظه عندي على الجهاز 💚", "memory_profile"
    result, category = core.vera_response(user_text)
    return result, category


def ai_reply(user_text, history, dialect):
    api_key = os.environ.get('OPENROUTER_API_KEY', '').strip()
    model = os.environ.get('OPENROUTER_MODEL', '').strip()
    if not api_key:
        return None, "api_not_configured"
    if not model:
        return "المفتاح موجود لكن اسم النموذج مش متحدد. اضبط OPENROUTER_MODEL في Termux.", "api_config"
    dialects = {
        'egyptian': 'اتكلم بالعامية المصرية الطبيعية فقط، كأنك بتتكلم مع صاحبك، من غير خلط إنجليزي بلا داعٍ.',
        'msa': 'استخدم العربية الفصحى المبسطة والواضحة.',
        'levantine': 'استخدم اللهجة الشامية الطبيعية.',
        'gulf': 'استخدم اللهجة الخليجية الطبيعية.',
        'saudi': 'استخدم اللهجة السعودية الطبيعية.',
        'english': 'Reply in natural conversational English.'
    }
    memory = core.memory_summary()
    recent = []
    for item in (history or [])[-12:]:
        if not isinstance(item, dict):
            continue
        role = item.get('role')
        content = str(item.get('content', '')).strip()
        if role in ('user', 'assistant') and content:
            recent.append({'role': role, 'content': content[:6000]})
    messages = [
        {'role': 'system', 'content': SYSTEM_BASE + '\n' + dialects.get(dialect, dialects['egyptian']) + '\n\nهذه ذاكرة محلية للمستخدم؛ قد تكون ناقصة، لا تخترع منها شيئًا:\n' + memory},
        *recent,
        {'role': 'user', 'content': str(user_text)[:6000]}
    ]
    payload = {'model': model, 'messages': messages, 'temperature': 0.55, 'max_tokens': 1100}
    req = Request('https://openrouter.ai/api/v1/chat/completions', data=json.dumps(payload, ensure_ascii=False).encode('utf-8'), headers={
        'Authorization': 'Bearer ' + api_key,
        'Content-Type': 'application/json',
        'HTTP-Referer': 'http://localhost:8765',
        'X-Title': 'VERA Web'
    }, method='POST')
    try:
        with urlopen(req, timeout=45) as resp:
            data = json.loads(resp.read().decode('utf-8'))
        choices = data.get('choices') or []
        content = choices[0].get('message', {}).get('content', '') if choices else ''
        if isinstance(content, list):
            content = '\n'.join(str(x.get('text', '')) for x in content if isinstance(x, dict))
        content = str(content).strip()
        if not content:
            return 'وصلني رد فاضي من نموذج الذكاء الاصطناعي. جرّب تاني.', 'ai_empty'
        return content, 'ai'
    except HTTPError as e:
        if e.code == 402:
            return 'الخدمة رفضت الطلب بسبب الرصيد أو حدود الاستخدام (402). مفيش حاجة اتحفظت من الرد.', 'api_error'
        if e.code == 401:
            return 'مفتاح OpenRouter غير صالح (401). راجع المفتاح في Termux من غير ما تبعتهولي.', 'api_error'
        if e.code == 429:
            return 'طلبات كتير أو وصلت لحد الاستخدام (429). استنى شوية وجرب تاني.', 'api_error'
        return f'خدمة الذكاء الاصطناعي رجعت خطأ HTTP {e.code}.', 'api_error'
    except (URLError, TimeoutError):
        return 'مش قادر أوصل لخدمة الذكاء الاصطناعي دلوقتي. اتأكد من النت وجرب تاني.', 'api_error'
    except Exception:
        return 'حصل خطأ غير متوقع في الاتصال بالنموذج. ماحفظتش الرد كحقيقة.', 'api_error'


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(STATIC), **kwargs)

    def log_message(self, fmt, *args):
        print('[VERA Web] ' + (fmt % args))

    def do_GET(self):
        path = urlparse(self.path).path
        if path == '/api/status':
            json_response(self, {
                'ok': True,
                'version': core.VERSION,
                'name': core.get_name(),
                'ai_configured': bool(os.environ.get('OPENROUTER_API_KEY', '').strip() and os.environ.get('OPENROUTER_MODEL', '').strip()),
                'memory': {'likes': len(core.MEMORY.get('likes', [])), 'goals': len(core.MEMORY.get('goals', [])), 'facts': len(core.MEMORY.get('facts', []))}
            })
            return
        if path == '/api/memory':
            json_response(self, {'summary': core.memory_summary(), 'timeline': core.memory_timeline()})
            return
        if path in ('/', '/index.html'):
            self.path = '/index.html'
        return super().do_GET()

    def do_POST(self):
        path = urlparse(self.path).path
        if path != '/api/chat':
            json_response(self, {'error': 'not found'}, 404)
            return
        try:
            size = int(self.headers.get('Content-Length', '0'))
            if size < 1 or size > 100_000:
                json_response(self, {'error': 'invalid request size'}, 413)
                return
            data = json.loads(self.rfile.read(size).decode('utf-8'))
            user_text = str(data.get('message', '')).strip()
            history = data.get('history', [])
            dialect = str(data.get('dialect', 'egyptian'))
            if not user_text:
                json_response(self, {'error': 'اكتب رسالة الأول.'}, 400)
                return
            if len(user_text) > 6000:
                json_response(self, {'error': 'الرسالة طويلة جدًا؛ اختصرها شوية.'}, 400)
                return
            # Always run explicit memory/name handling before the model.
            if clean_name_from_message(user_text) or asks_name(user_text):
                reply, category = local_reply(user_text)
            else:
                reply, category = local_reply(user_text)
                # Only known explicit local commands should bypass the AI. This prevents
                # incidental keyword/context matches from answering unrelated questions.
                if category not in LOCAL_ONLY_CATEGORIES:
                    if os.environ.get('OPENROUTER_API_KEY', '').strip():
                        ai, ai_category = ai_reply(user_text, history, dialect)
                        if ai is not None:
                            reply, category = ai, ai_category
                    else:
                        reply = 'لسه محتاجة توصيل نموذج ذكاء اصطناعي عشان أجاوب السؤال ده بدقة. الذاكرة المحلية شغالة، لكن مفيش API متوصل حاليًا. 💚'
                        category = 'api_not_configured'
            try:
                core.save_conversation(user_text, reply)
                core.save_self_evaluation(user_text, reply, core.confidence_for_response(reply, category), category)
            except Exception:
                pass
            json_response(self, {'reply': reply, 'category': category, 'name': core.get_name(), 'ai_configured': bool(os.environ.get('OPENROUTER_API_KEY', '').strip() and os.environ.get('OPENROUTER_MODEL', '').strip())})
        except json.JSONDecodeError:
            json_response(self, {'error': 'الطلب مش مفهوم.'}, 400)
        except Exception as e:
            print('[VERA Web] request error:', repr(e))
            json_response(self, {'error': 'حصل خطأ داخلي. راجع شاشة Termux.'}, 500)


def main():
    server = ThreadingHTTPServer(('127.0.0.1', PORT), Handler)
    print('\n=====================================')
    print(f' VERA Web {core.VERSION} is running')
    print(f' افتح المتصفح على: http://127.0.0.1:{PORT}')
    print(' لإيقاف السيرفر: اضغط Ctrl+C')
    print('=====================================\n')
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print('\nVERA Web stopped.')
    finally:
        server.server_close()

if __name__ == '__main__':
    main()
