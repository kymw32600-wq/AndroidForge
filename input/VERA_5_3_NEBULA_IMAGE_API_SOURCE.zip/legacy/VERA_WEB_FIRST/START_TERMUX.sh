#!/data/data/com.termux/files/usr/bin/bash
set -eu
cd "$(dirname "$0")"
echo "VERA Web is starting..."
echo "When you see the URL, open Chrome and visit http://127.0.0.1:8765"
python server.py
