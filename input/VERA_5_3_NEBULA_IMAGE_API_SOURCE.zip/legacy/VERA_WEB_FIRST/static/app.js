const $ = (s) => document.querySelector(s);
const messagesEl = $('#messages');
const input = $('#messageInput');
const form = $('#chatForm');
const sendBtn = $('#sendBtn');
const micBtn = $('#micBtn');
const speakToggle = $('#speakToggle');
const dialectSelect = $('#dialect');
const voiceSelect = $('#voiceSelect');
const testVoiceBtn = $('#testVoiceBtn');
const stopVoiceBtn = $('#stopVoiceBtn');
const history = [];
let listening = false;
let sending = false;
let recognition = null;
let toastTimer;
let availableVoices = [];
let speechRate = Number(localStorage.getItem('veraSpeechRate') || '0.96');

function toast(text){const el=$('#toast');el.textContent=text;el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),2600)}
function escapeText(s){return String(s)}
function addMessage(role, text, category=''){
  $('#welcome').style.display='none';
  const row=document.createElement('div');row.className=`message ${role}`;
  const avatar=document.createElement('div');avatar.className='avatar';avatar.textContent=role==='user'?'أنت':'V';
  const wrap=document.createElement('div');wrap.className='message-wrap';
  const bubble=document.createElement('div');bubble.className='bubble';bubble.textContent=escapeText(text);
  const meta=document.createElement('div');meta.className='meta';meta.textContent=role==='assistant'?(category==='ai'?'VERA • AI':'VERA • ذاكرة محلية'):'أنت';
  wrap.append(bubble,meta);row.append(avatar,wrap);messagesEl.append(row);row.scrollIntoView({behavior:'smooth',block:'end'});
  return row;
}
function targetLang(){const d=dialectSelect.value;return d==='english'?'en':d==='saudi'||d==='gulf'?'ar-SA':d==='levantine'?'ar-LB':d==='msa'?'ar':'ar-EG'}
function chooseVoice(){
  const chosen=voiceSelect.value;
  const genderPattern=chosen==='__male__'?/(male|man|masculine|رجل|ذكور)/i:chosen==='__female__'?/(female|woman|feminine|امرأة|أنثى|انثى)/i:null;
  const lang=targetLang();
  if(genderPattern){const match=availableVoices.find(v=>v.lang.toLowerCase().startsWith(lang.split('-')[0])&&genderPattern.test(v.name));if(match)return match;toast(chosen==='__male__'?'مش ظاهر اسم صوت رجالي واضح في أصوات الجهاز؛ اختار صوتًا من القائمة أو ثبّت صوتًا آخر من إعدادات Android.':'مش ظاهر اسم صوت نسائي واضح في أصوات الجهاز؛ اختار صوتًا من القائمة أو ثبّت صوتًا آخر من إعدادات Android.');return null}
  if(chosen&&chosen!=='__male__'&&chosen!=='__female__'){const found=availableVoices.find(v=>v.voiceURI===chosen);if(found)return found}
  return availableVoices.find(v=>v.lang===lang)||availableVoices.find(v=>v.lang.startsWith(lang.split('-')[0]))||availableVoices.find(v=>v.lang.startsWith('ar'))||null;
}
function speak(text){
  if(!speakToggle.checked||!('speechSynthesis' in window))return;
  window.speechSynthesis.cancel();
  const utter=new SpeechSynthesisUtterance(String(text).slice(0,1800));
  const voice=chooseVoice();
  utter.lang=voice?.lang||targetLang();
  if(voice)utter.voice=voice;
  utter.rate=speechRate; utter.pitch=1.0;
  window.speechSynthesis.speak(utter);
}
function loadVoices(){
  if(!('speechSynthesis' in window)){voiceSelect.innerHTML='<option value="">الصوت غير مدعوم</option>';$('#voiceNote').textContent='المتصفح لا يدعم إخراج الصوت هنا.';return}
  availableVoices=window.speechSynthesis.getVoices()||[];
  const old=localStorage.getItem('veraVoice')||'';
  voiceSelect.innerHTML='';
  const auto=document.createElement('option');auto.value='';auto.textContent='أفضل صوت متاح تلقائيًا';voiceSelect.append(auto);
  const male=document.createElement('option');male.value='__male__';male.textContent='صوت رجالي (لو متاح)';voiceSelect.append(male);
  const female=document.createElement('option');female.value='__female__';female.textContent='صوت نسائي (لو متاح)';voiceSelect.append(female);
  availableVoices.forEach(v=>{const o=document.createElement('option');o.value=v.voiceURI;o.textContent=`${v.name} — ${v.lang}${v.default?' • افتراضي':''}`;voiceSelect.append(o)});
  if(old==='__male__'||old==='__female__'||availableVoices.some(v=>v.voiceURI===old))voiceSelect.value=old;
  const arabic=availableVoices.filter(v=>v.lang.toLowerCase().startsWith('ar')).length;
  $('#voiceNote').textContent=availableVoices.length?`متاح ${availableVoices.length} صوت على جهازك، منها ${arabic} عربي. طبيعية الصوت وتوفر صوت رجالي بيعتمدوا على الأصوات المثبّتة في Android.`:'المتصفح لسه ما عرضش أصوات الجهاز. جرّب تفتح الصفحة في Chrome أو ثبّت صوتًا من إعدادات تحويل النص إلى كلام في Android.';
}
function setBusy(b){sendBtn.disabled=b;sendBtn.textContent=b?'…':'➤'}
function detectDialectCommand(text){
  const t=String(text).toLowerCase();
  const rules=[
    ['egyptian',/((كلمني|كلميني|اتكلم|تكلم|احكي|رد عليا|عايزك|خليكي|من دلوقتي).{0,28}(مصري|مصرى|عامية مصرية|بالعامية المصرية))|(باللهجة المصرية|مصري كده|بالمصري)/],
    ['msa',/((كلمني|كلميني|اتكلم|تكلم|رد|عايزك|خليكي|من دلوقتي).{0,28}(فصحى|عربي فصيح|العربية الفصحى))|(بالفصحى)/],
    ['saudi',/((كلمني|كلميني|اتكلم|تكلم|رد|عايزك|خليكي|من دلوقتي).{0,28}(سعودي|سعودية))|(باللهجة السعودية|بالسعودي)/],
    ['gulf',/((كلمني|كلميني|اتكلم|تكلم|رد|عايزك|خليكي|من دلوقتي).{0,28}(خليجي|خليجية))|(باللهجة الخليجية|بالخليجي)/],
    ['levantine',/((كلمني|كلميني|اتكلم|تكلم|رد|عايزك|خليكي|من دلوقتي).{0,28}(شامي|شامية|لبناني|سوري|أردني|اردني))|(باللهجة الشامية|بالشامي)/],
    ['english',/((كلمني|كلميني|اتكلم|تكلم|رد|عايزك|خليكي|من دلوقتي).{0,28}(إنجليزي|انجليزي|english))|(speak in english|talk to me in english)/]
  ];
  for(const [value,re] of rules)if(re.test(t))return value;
  return null;
}
async function sendMessage(text){if(sending)return;text=(text??input.value).trim();if(!text)return;const requestedDialect=detectDialectCommand(text);if(requestedDialect){dialectSelect.value=requestedDialect;localStorage.setItem('veraDialect',requestedDialect);if(recognition)recognition.lang=targetLang();toast(`تمام، هكلمك ${dialectSelect.options[dialectSelect.selectedIndex].text} من دلوقتي 💚`)}sending=true;input.value='';input.style.height='auto';addMessage('user',text);history.push({role:'user',content:text});setBusy(true);const typing=addMessage('assistant','بفكر معاك…','typing');typing.classList.add('typing');try{const r=await fetch('/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:text,history:history.slice(-12,-1),dialect:dialectSelect.value})});const data=await r.json();typing.remove();if(!r.ok)throw new Error(data.error||'حصل خطأ');addMessage('assistant',data.reply,data.category);history.push({role:'assistant',content:data.reply});if(history.length>30)history.splice(0,history.length-30);speak(data.reply);if(data.name)$('#subtitle').textContent=`أهلًا ${data.name} • VERA ${'3.5.0'}`;refreshStatus();}catch(e){typing.remove();addMessage('assistant',`مش عارف أكمل الطلب دلوقتي: ${e.message}`,'error')}finally{sending=false;setBusy(false);input.focus()}}
form.addEventListener('submit',e=>{e.preventDefault();sendMessage()});
input.addEventListener('input',()=>{input.style.height='auto';input.style.height=Math.min(input.scrollHeight,130)+'px'});
input.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();form.requestSubmit()}});
document.querySelectorAll('[data-prompt]').forEach(b=>b.addEventListener('click',()=>sendMessage(b.dataset.prompt)));
async function refreshStatus(){try{const r=await fetch('/api/status');const d=await r.json();$('#connectionStatus').textContent=d.ai_configured?'🟢 الذكاء الاصطناعي متصل':'🟡 الذاكرة المحلية تعمل • API غير مضبوط';if(d.name)$('#subtitle').textContent=`أهلًا ${d.name} • نسخة الويب المطوّرة`;}catch{$('#connectionStatus').textContent='تعذر الاتصال بالسيرفر المحلي'}}
$('#memoryBtn').addEventListener('click',openMemory);$('#closeMemory').addEventListener('click',()=>{$('#memoryPanel').classList.remove('open');$('#memoryPanel').setAttribute('aria-hidden','true')});$('#refreshMemory').addEventListener('click',loadMemory);
function openMemory(){const p=$('#memoryPanel');p.classList.add('open');p.setAttribute('aria-hidden','false');loadMemory()}
async function loadMemory(){try{const r=await fetch('/api/memory');const d=await r.json();$('#memoryContent').textContent=d.summary+'\n\n'+d.timeline}catch{$('#memoryContent').textContent='تعذر تحميل الذاكرة.'}}
function setupSpeech(){const SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR){micBtn.addEventListener('click',()=>toast('التعرف على الصوت غير مدعوم في المتصفح ده. جرّب Chrome.'));return}recognition=new SR();recognition.continuous=false;recognition.interimResults=true;recognition.lang='ar-EG';let finalText='';recognition.onstart=()=>{listening=true;finalText='';micBtn.classList.add('listening');micBtn.textContent='⏹️';toast('سامعاك… اتكلم دلوقتي 🎙️')};recognition.onresult=e=>{let interim='';for(let i=e.resultIndex;i<e.results.length;i++){const t=e.results[i][0].transcript;if(e.results[i].isFinal)finalText+=t;else interim+=t}input.value=(finalText||interim).trim();input.style.height='auto';input.style.height=Math.min(input.scrollHeight,130)+'px'};recognition.onerror=e=>{toast(e.error==='not-allowed'?'اسمح للمتصفح باستخدام الميكروفون.':'التعرف على الصوت وقف؛ جرّب تاني.');stopListening()};recognition.onend=()=>{const t=(finalText||input.value).trim();stopListening();if(t)sendMessage(t)};micBtn.addEventListener('click',()=>{if(listening){recognition.stop();return}try{recognition.lang=targetLang()==='en'?'en-US':targetLang();recognition.start()}catch{toast('استنى ثانية وجرب تاني.')}})}
function stopListening(){listening=false;micBtn.classList.remove('listening');micBtn.textContent='🎙️'}
dialectSelect.addEventListener('change',()=>{localStorage.setItem('veraDialect',dialectSelect.value);if(recognition)recognition.lang=targetLang()==='en'?'en-US':targetLang()});
voiceSelect.addEventListener('change',()=>{localStorage.setItem('veraVoice',voiceSelect.value);if(voiceSelect.value==='__male__'||voiceSelect.value==='__female__'){const v=chooseVoice();if(v)$('#voiceNote').textContent=`هنستخدم أقرب صوت متاح للاختيار ده: ${v.name} (${v.lang}). لو مش مناسب، اختار صوتًا محددًا من القائمة.`}else if(voiceSelect.value){const v=availableVoices.find(x=>x.voiceURI===voiceSelect.value);if(v)$('#voiceNote').textContent=`الصوت المختار: ${v.name} (${v.lang}). لو الصوت مش مناسب، اختار غيره من القائمة.`}});
testVoiceBtn.addEventListener('click',()=>speak(dialectSelect.value==='english'?'Hi! I am VERA. Let us talk naturally.':'أهلًا، أنا فيرا. جرّب كده الصوت اللي اخترته، ولو مش عاجبك نغيّره سوا.'));
stopVoiceBtn.addEventListener('click',()=>{if('speechSynthesis' in window)window.speechSynthesis.cancel();toast('وقفت قراءة الصوت.')});
const savedDialect=localStorage.getItem('veraDialect');if(savedDialect)dialectSelect.value=savedDialect;
if('speechSynthesis' in window){loadVoices();window.speechSynthesis.onvoiceschanged=loadVoices;setTimeout(loadVoices,700)}
setupSpeech();refreshStatus();
