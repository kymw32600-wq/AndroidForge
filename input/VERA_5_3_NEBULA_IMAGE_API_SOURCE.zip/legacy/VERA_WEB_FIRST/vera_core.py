import os
import re
import json
import uuid
import hashlib
from datetime import datetime
from pathlib import Path
from difflib import SequenceMatcher
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

BASE_DIR = Path(__file__).resolve().parent

MEMORY_FILE = BASE_DIR / "memory.txt"
MEMORY_V2_FILE = BASE_DIR / "memory_v2.json"
PLAN_FILE = BASE_DIR / "plans.txt"
IDENTITY_FILE = BASE_DIR / "identity.json"
CONVERSATION_FILE = BASE_DIR / "conversation.txt"
KNOWLEDGE_FILE = BASE_DIR / "knowledge_graph.json"
SELF_EVAL_FILE = BASE_DIR / "self_evaluation.json"
LEARNING_FILE = BASE_DIR / "learning_cases.json"

VERSION = "3.5.0"


def timestamp():
    return datetime.now().isoformat(timespec="seconds")


def normalize_text(text):
    text = str(text).strip().lower()
    # Ignore question marks so command matching works with or without punctuation.
    text = text.replace("؟", " ").replace("?", " ")

    replacements = {
        "أ": "ا",
        "إ": "ا",
        "آ": "ا",
        "ة": "ه",
        "ى": "ي",
        "ؤ": "و",
        "ئ": "ي",
    }

    for old, new in replacements.items():
        text = text.replace(old, new)

    text = re.sub(
        r"[^\w\s\u0600-\u06FF.+*/%()×÷\-]",
        " ",
        text
    )

    text = re.sub(r"\s+", " ", text)

    return text.strip()


def convert_arabic_digits(text):
    return str(text).translate(
        str.maketrans(
            "٠١٢٣٤٥٦٧٨٩",
            "0123456789"
        )
    )


def safe_json_load(path, default):
    try:
        if not path.exists():
            return default

        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)

    except Exception:
        return default


def safe_json_save(path, data):
    """Write JSON atomically so an interrupted write is less likely to corrupt a file."""
    path = Path(path)
    temp_path = path.with_name(path.name + ".tmp")
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(temp_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
            f.flush()
            os.fsync(f.fileno())
        os.replace(temp_path, path)
        return True
    except Exception:
        try:
            temp_path.unlink(missing_ok=True)
        except Exception:
            pass
        return False


# =========================================================
# DIGITAL IDENTITY
# =========================================================

def load_identity():

    identity = safe_json_load(
        IDENTITY_FILE,
        None
    )

    if identity:
        identity["version"] = VERSION
        identity["capabilities"] = [
            "long_term_memory",
            "memory_timeline",
            "memory_deduplication",
            "memory_conflict_detection",
            "knowledge_graph",
            "reasoning_engine",
            "goal_engine",
            "planning",
            "self_evaluation",
            "truthfulness_core",
            "confidence_layer",
            "conversation_context",
            "digital_identity"
        ]

        safe_json_save(
            IDENTITY_FILE,
            identity
        )

        return identity

    identity = {
        "id": str(uuid.uuid4()),
        "name": "VERA 2.2",
        "version": VERSION,
        "created_at": timestamp(),
        "memory_version": 3,
        "architecture": "LOCAL_EVOLUTION_CORE",
        "capabilities": [
            "long_term_memory",
            "memory_timeline",
            "memory_deduplication",
            "memory_conflict_detection",
            "knowledge_graph",
            "reasoning_engine",
            "goal_engine",
            "planning",
            "self_evaluation",
            "truthfulness_core",
            "confidence_layer",
            "conversation_context",
            "digital_identity"
        ]
    }

    safe_json_save(
        IDENTITY_FILE,
        identity
    )

    return identity


IDENTITY = load_identity()


def code_fingerprint():

    try:
        with open(__file__, "rb") as f:
            return hashlib.sha256(
                f.read()
            ).hexdigest()

    except Exception:
        return "غير متاح"


def identity_command():

    return (
        "هوية VERA:\n"
        f"- الاسم: VERA\n"
        f"- ID: {IDENTITY['id']}\n"
        f"- الإصدار: {VERSION}\n"
        f"- تاريخ الإنشاء: {IDENTITY['created_at']}\n"
        f"- Memory Version: {IDENTITY['memory_version']}\n"
        f"- Code SHA-256: {code_fingerprint()}\n"
        "- الحالة: LOCAL EVOLUTION CORE\n\n"
        "دي هوية محلية وبصمة للكود، "
        "وليست نظام مصادقة."
    )


# =========================================================
# TRUTHFULNESS CORE
# =========================================================

TRUTHFULNESS_RULES = [
    "أميز بين الذاكرة والمعلومة الخارجية.",
    "لو المعلومة غير موجودة عندي أقول إني مش عارف.",
    "لا أقدم التخمين على أنه حقيقة.",
    "لا أختلق مصادر أو مراجع.",
    "لا أدعي التحقق من الإنترنت بدون اتصال حقيقي.",
    "معلومات المستخدم عن نفسه تعامل كذاكرة شخصية.",
    "لو فيه تعارض في الذاكرة أظهر التعارض.",
    "الثقة في الإجابة لا تعني أنها حقيقة مطلقة.",
    "المعلومات التي تحتاج تحقق خارجي لا أعتبرها مؤكدة محليًا."
]


def truthfulness_command():

    lines = [
        "VERA Truthfulness Core:",
        ""
    ]

    for i, rule in enumerate(
        TRUTHFULNESS_RULES,
        1
    ):
        lines.append(
            f"{i}. {rule}"
        )

    lines.append("")
    lines.append(
        "الحالة: LOCAL TRUST LAYER"
    )

    return "\n".join(lines)


def unknown_response():

    return (
        "مش لاقي إجابة موثوقة عندي للجملة دي.\n"
        "ومش هخمن وأقدم التخمين كأنه حقيقة."
    )


# =========================================================
# OPTIONAL OPENROUTER AI CONNECTION
# Uses only Python's standard library; no extra pip package.
# Configure OPENROUTER_API_KEY and OPENROUTER_MODEL in Termux.
# Never store the API key in this source file or in memory files.
# =========================================================

def ai_connection_status():
    api_key = os.environ.get("OPENROUTER_API_KEY", "").strip()
    model = os.environ.get("OPENROUTER_MODEL", "").strip()
    if not api_key:
        return "غير متصل: مفتاح OPENROUTER_API_KEY غير مضبوط."
    if not model:
        return "المفتاح موجود، لكن OPENROUTER_MODEL غير مضبوط. اختر اسم نموذج من OpenRouter."
    verifier = "مفعّل (طلب إضافي قد يزيد التكلفة)" if os.environ.get("VERA_VERIFY_RESPONSE", "0").strip() == "1" else "متوقف لتقليل التكلفة"
    return f"الإعدادات موجودة للنموذج: {model}. فحص الاتساق مع الذاكرة: {verifier}. الاتصال الفعلي يتأكد عند أول طلب."


def verify_response_against_memory(user_query, draft, memory_context, api_key, model):
    """Optional second-pass consistency check against local memory only (not external fact-checking)."""
    prompt = (
        "أنت مدقق اتساق داخل VERA. لا تتحقق من الإنترنت ولا تدّعِ التحقق الخارجي. "
        "راجع المسودة فقط بحثًا عن تناقض مباشر مع ذاكرة المستخدم المحلية. "
        "الذاكرة قد تكون ناقصة أو قديمة؛ لا تخترع حقائق جديدة. "
        "إذا وجدت تناقضًا واضحًا، صحح الجزء المتناقض فقط. إذا لم تجد تناقضًا، أعد المسودة كما هي. "
        "إذا لم تكفِ الذاكرة للحكم، أعد المسودة كما هي وأضف تنبيهًا قصيرًا بأنها غير مؤكدة من الذاكرة.\n\n"
        f"سؤال المستخدم: {user_query}\n"
        f"الذاكرة المحلية: {memory_context}\n"
        f"المسودة: {draft}"
    )
    payload = {
        "model": model,
        "messages": [{"role": "system", "content": prompt}],
        "temperature": 0.1,
        "max_tokens": 450
    }
    request = Request(
        "https://openrouter.ai/api/v1/chat/completions",
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "HTTP-Referer": "https://vera.local",
            "X-Title": "VERA 2.2 consistency check"
        },
        method="POST"
    )
    with urlopen(request, timeout=30) as response:
        data = json.loads(response.read().decode("utf-8"))
    choices = data.get("choices", [])
    if not choices:
        raise ValueError("empty verifier response")
    checked = choices[0].get("message", {}).get("content", "")
    if isinstance(checked, list):
        checked = "\n".join(str(part.get("text", "")) for part in checked if isinstance(part, dict))
    checked = str(checked).strip()
    return checked or draft


def openrouter_response(user_query):
    """Answer an otherwise-unhandled question through OpenRouter, if configured.

    AI answers are returned to the user but are NOT automatically saved as facts.
    """
    api_key = os.environ.get("OPENROUTER_API_KEY", "").strip()
    model = os.environ.get("OPENROUTER_MODEL", "").strip()

    if not api_key:
        return None
    if not model:
        return "مفتاح OpenRouter موجود، لكن اسم النموذج غير مضبوط. اضبط OPENROUTER_MODEL أولًا."

    # Only provide a small number of potentially relevant memories; similarity is not proof.
    memories = search_memory(user_query)
    relevant = [m for m in memories if m.get("score", 0) >= 0.45][:4]
    memory_lines = []
    for item in relevant:
        category = item.get("category", "memory")
        value = str(item.get("text", "")).strip()
        if value:
            memory_lines.append(f"- ({category}) {value}")
    memory_context = "\n".join(memory_lines) if memory_lines else "لا توجد حقائق محلية مسترجعة بدرجة مناسبة."

    system_prompt = (
        "أنت VERA 2.2، مساعد مباشر وصادق. أجب بلغة المستخدم وباختصار مناسب. "
        "لا تدّعِ أنك تحققت من الإنترنت أو من مصدر خارجي إذا لم تفعل. "
        "إذا كانت المعلومة حديثة أو غير مؤكدة، وضّح حدود معرفتك واطلب مصدرًا أو قل إنك لا تستطيع تأكيدها. "
        "لا تخترع حقائق عن المستخدم. الذاكرة المحلية التالية سياق مساعد فقط وقد تكون ناقصة أو قديمة؛ "
        "لا تعتبرها دليلًا على حقائق عامة، وإذا تعارضت فلا تخفِ التعارض. "
        "لا تضف سؤال المستخدم أو إجابتك إلى الذاكرة كحقيقة تلقائيًا.\n\n"
        f"سياق ذاكرة المستخدم المحلي:\n{memory_context}"
    )
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": str(user_query)}
        ],
        "temperature": 0.3,
        "max_tokens": 450
    }
    request = Request(
        "https://openrouter.ai/api/v1/chat/completions",
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "HTTP-Referer": "https://vera.local",
            "X-Title": "VERA 2.2"
        },
        method="POST"
    )

    try:
        with urlopen(request, timeout=30) as response:
            data = json.loads(response.read().decode("utf-8"))
        choices = data.get("choices", [])
        if not choices:
            return "خدمة الذكاء الاصطناعي رجعت ردًا فارغًا؛ لم يتم حفظ أي معلومة."
        content = choices[0].get("message", {}).get("content", "")
        if isinstance(content, list):
            content = "\n".join(
                str(part.get("text", "")) for part in content if isinstance(part, dict)
            )
        content = str(content).strip()
        if not content:
            return "الرد وصل فارغًا من النموذج؛ لم يتم حفظ أي معلومة."

        # A second API call costs extra, so it is OFF unless explicitly enabled.
        if os.environ.get("VERA_VERIFY_RESPONSE", "0").strip() == "1":
            try:
                content = verify_response_against_memory(
                    user_query, content, memory_context, api_key, model
                )
            except Exception:
                return content + "\n\nتنبيه: تعذر فحص التوافق مع الذاكرة؛ اعتبر الإجابة غير مؤكدة."
        return content
    except HTTPError as exc:
        if exc.code == 401:
            return "تعذر الاتصال بـ OpenRouter: المفتاح غير صحيح أو غير صالح (401)."
        if exc.code == 402:
            return "تعذر إكمال الطلب: الرصيد أو حدود الاستخدام غير كافية (402). لم يتم حفظ أي معلومة."
        if exc.code == 429:
            return "طلبات OpenRouter كثيرة أو وصلت لحد الاستخدام (429). جرّب لاحقًا."
        return f"تعذر الاتصال بخدمة الذكاء الاصطناعي (HTTP {exc.code}). لم يتم حفظ أي معلومة."
    except URLError:
        return "مش قادر أوصل لـ OpenRouter حاليًا. راجع اتصال الإنترنت وحاول تاني."
    except TimeoutError:
        return "اتأخر رد OpenRouter وانتهت مهلة الاتصال. جرّب مرة أخرى."
    except (json.JSONDecodeError, KeyError, TypeError, ValueError):
        return "وصل رد غير مفهوم من خدمة الذكاء الاصطناعي. لم يتم حفظ أي معلومة."
    except Exception:
        return "حصل خطأ غير متوقع أثناء طلب الذكاء الاصطناعي. لم يتم حفظ أي معلومة."


def ai_status_command(text):
    if normalize_text(text) in {
        "حالة الذكاء الاصطناعي", "حاله الذكاء الاصطناعي",
        "حالة api", "api status", "ai status", "حالة الاتصال"
    }:
        return "حالة اتصال VERA:\n" + ai_connection_status()
    return None


# =========================================================
# MEMORY
# =========================================================

CATEGORIES = [
    "profile",
    "preferences",
    "likes",
    "dislikes",
    "goals",
    "projects",
    "facts",
    "events"
]


def empty_memory():

    return {
        "version": 3,
        "profile": {},
        "preferences": [],
        "likes": [],
        "dislikes": [],
        "goals": [],
        "projects": [],
        "facts": [],
        "events": []
    }


def migrate_old_memory():

    data = empty_memory()

    if MEMORY_FILE.exists():

        try:

            with open(
                MEMORY_FILE,
                "r",
                encoding="utf-8"
            ) as f:

                lines = [
                    line.strip()
                    for line in f
                    if line.strip()
                ]

            for line in lines:

                low = line.lower()

                if low.startswith("name:"):

                    value = line.split(
                        ":",
                        1
                    )[1].strip()

                    if value:
                        data["profile"]["name"] = value

                elif low.startswith("likes:"):

                    value = line.split(
                        ":",
                        1
                    )[1].strip()

                    if value:
                        data["likes"].append({
                            "text": value,
                            "created_at": timestamp(),
                            "source": "migration"
                        })

                elif low.startswith("goals:"):

                    value = line.split(
                        ":",
                        1
                    )[1].strip()

                    if value:
                        data["goals"].append({
                            "text": value,
                            "created_at": timestamp(),
                            "source": "migration"
                        })

                elif low.startswith("fact:"):

                    value = line.split(
                        ":",
                        1
                    )[1].strip()

                    if value:
                        data["facts"].append({
                            "text": value,
                            "created_at": timestamp(),
                            "source": "migration"
                        })

        except Exception:
            pass

    safe_json_save(
        MEMORY_V2_FILE,
        data
    )

    return data


def load_memory():

    data = safe_json_load(
        MEMORY_V2_FILE,
        None
    )

    if data is None:
        return migrate_old_memory()

    for category in CATEGORIES:

        if category not in data:

            data[category] = (
                {}
                if category == "profile"
                else []
            )

    data["version"] = 3

    return data


MEMORY = load_memory()


def save_memory():

    safe_json_save(
        MEMORY_V2_FILE,
        MEMORY
    )

    # Once the graph subsystem has loaded, keep it in sync with explicit memory.
    sync = globals().get("sync_memory_to_graph")
    if callable(sync):
        sync()


def similarity(a, b):

    a = normalize_text(a)
    b = normalize_text(b)

    if not a or not b:
        return 0

    return SequenceMatcher(
        None,
        a,
        b
    ).ratio()


def get_name():

    return MEMORY.get(
        "profile",
        {}
    ).get("name")


def detect_memory_key(text):

    normalized = normalize_text(text)

    patterns = [
        (
            "لوني المفضل",
            "favorite_color"
        ),
        (
            "favorite color",
            "favorite_color"
        ),
        (
            "my favorite color",
            "favorite_color"
        )
    ]

    for pattern, key in patterns:

        if normalize_text(pattern) in normalized:
            return key

    return None


def get_keyed_memory(key):
    """Return the newest current value for a keyed fact, not a historical value."""
    matches = []
    for category in CATEGORIES:
        if category in ("profile", "events"):
            continue
        for item in MEMORY.get(category, []):
            if item.get("key") == key:
                matches.append(item)
    if not matches:
        return None
    matches.sort(key=lambda item: str(item.get("created_at", "")), reverse=True)
    return matches[0].get("text", "")


def add_memory(
    category,
    text,
    source="user"
):

    text = str(text).strip()

    if not text:
        return False

    if category == "profile":

        old_name = get_name()

        if old_name == text:
            return False

        if old_name:

            MEMORY["events"].append({
                "text": old_name,
                "created_at": timestamp(),
                "source": "history",
                "key": "name"
            })

        MEMORY["profile"]["name"] = text

        save_memory()

        return True

    if category not in CATEGORIES:
        return False

    normalized = normalize_text(text)
    key = detect_memory_key(text)

    if key:

        current_items = [
            item for item in MEMORY[category]
            if item.get("key") == key
        ]
        latest_item = max(
            current_items,
            key=lambda item: str(item.get("created_at", "")),
            default=None
        )

        if latest_item and normalize_text(latest_item.get("text", "")) == normalized:
            # If legacy duplicates exist, collapse them without changing the current value.
            if len(current_items) > 1:
                MEMORY[category] = [
                    item for item in MEMORY[category]
                    if item.get("key") != key
                ] + [latest_item]
                save_memory()
            return False

        # Keep every distinct prior keyed value in the timeline before replacing it.
        for old_item in current_items:
            if normalize_text(old_item.get("text", "")) != normalized:
                MEMORY["events"].append({
                    "text": old_item.get("text", ""),
                    "created_at": old_item.get("created_at", timestamp()),
                    "source": "history",
                    "key": key
                })

        if current_items:
            MEMORY[category] = [
                item for item in MEMORY[category]
                if item.get("key") != key
            ]

        MEMORY[category].append({
            "text": text,
            "created_at": timestamp(),
            "source": source,
            "key": key
        })

        save_memory()

        return True

    for item in MEMORY[category]:

        if similarity(
            item.get("text", ""),
            text
        ) >= 0.90:

            return False

    MEMORY[category].append({
        "text": text,
        "created_at": timestamp(),
        "source": source
    })

    save_memory()

    return True


def search_memory(query):

    query = normalize_text(query)

    results = []

    name = get_name()

    if name:

        score = similarity(
            query,
            name
        )

        if score >= 0.60:

            results.append({
                "score": score,
                "category": "profile",
                "text": name
            })

    for category in CATEGORIES:

        if category in (
            "profile",
            "events"
        ):
            continue

        for item in MEMORY.get(
            category,
            []
        ):

            value = item.get(
                "text",
                ""
            )

            score = similarity(
                query,
                value
            )

            if score >= 0.60:

                results.append({
                    "score": score,
                    "category": category,
                    "text": value
                })

    results.sort(
        key=lambda x: x["score"],
        reverse=True
    )

    return results[:10]


def memory_summary():

    output = [
        "VERA Memory v3:"
    ]

    name = get_name()

    if name:

        output.append(
            "\nالاسم:\n"
            f"  • {name}"
        )

    labels = {
        "preferences": "التفضيلات",
        "likes": "الحاجات اللي بتحبها",
        "dislikes": "الحاجات اللي مش بتحبها",
        "goals": "الأهداف",
        "projects": "المشاريع",
        "facts": "المعلومات",
        "events": "التاريخ"
    }

    for category, label in labels.items():

        items = MEMORY.get(
            category,
            []
        )

        if not items:
            continue

        output.append(
            f"\n{label}:"
        )

        for item in items[-20:]:

            output.append(
                f"  • {item.get('text', '')}"
            )

    return "\n".join(output)


def memory_timeline(query=""):

    query = normalize_text(query)

    events = MEMORY.get(
        "events",
        []
    )

    matches = []

    query_key = detect_memory_key(query) if query else None

    for item in events:

        value = item.get(
            "text",
            ""
        )

        event_key = item.get("key")

        if (
            not query
            or query in normalize_text(value)
            or (query_key and event_key == query_key)
            or (query and query in normalize_text(event_key or ""))
        ):

            matches.append(item)

    if not matches:

        return (
            "مش لاقي تاريخ محفوظ للمعلومة دي."
        )

    lines = [
        "📜 سجل الذاكرة:"
    ]

    for item in matches[-20:]:

        lines.append(
            "• "
            + item.get(
                "text",
                ""
            )
            + " — "
            + item.get(
                "created_at",
                "وقت غير معروف"
            )
        )

    return "\n".join(lines)


def clear_memory():

    global MEMORY

    MEMORY = empty_memory()

    save_memory()

    return (
        "تمام، مسحت الذاكرة المنظمة."
    )


# =========================================================
# KNOWLEDGE GRAPH
# =========================================================

def load_graph():

    default = {
        "version": 1,
        "nodes": [],
        "edges": []
    }

    return safe_json_load(
        KNOWLEDGE_FILE,
        default
    )


KNOWLEDGE = load_graph()


def save_graph():

    return safe_json_save(
        KNOWLEDGE_FILE,
        KNOWLEDGE
    )


def add_node(name, node_type="concept"):

    name = str(name).strip()

    if not name:
        return False

    normalized = normalize_text(name)

    for node in KNOWLEDGE["nodes"]:

        if normalize_text(
            node.get("name", "")
        ) == normalized:

            return False

    KNOWLEDGE["nodes"].append({
        "id": str(uuid.uuid4()),
        "name": name,
        "type": node_type,
        "created_at": timestamp()
    })

    save_graph()

    return True


def add_relation(
    source,
    relation,
    target
):

    source = str(source).strip()
    relation = str(relation).strip()
    target = str(target).strip()

    if not source or not relation or not target:
        return False

    add_node(source)
    add_node(target)

    for edge in KNOWLEDGE["edges"]:

        if (
            normalize_text(
                edge.get("source", "")
            ) == normalize_text(source)
            and normalize_text(
                edge.get("relation", "")
            ) == normalize_text(relation)
            and normalize_text(
                edge.get("target", "")
            ) == normalize_text(target)
        ):

            return False

    KNOWLEDGE["edges"].append({
        "source": source,
        "relation": relation,
        "target": target,
        "created_at": timestamp()
    })

    save_graph()

    return True


def sync_memory_to_graph():
    """Create conservative graph links from explicit saved memory only."""
    person = get_name()
    if not person:
        return

    add_node(person, "person")

    for category, relation, node_type in (
        ("likes", "likes", "interest"),
        ("dislikes", "dislikes", "interest"),
        ("goals", "has_goal", "goal"),
        ("projects", "works_on", "project"),
        ("facts", "has_fact", "fact"),
    ):
        for item in MEMORY.get(category, []):
            value = str(item.get("text", "")).strip()
            if value:
                add_node(value, node_type)
                add_relation(person, relation, value)


def graph_summary():

    nodes = KNOWLEDGE.get(
        "nodes",
        []
    )

    edges = KNOWLEDGE.get(
        "edges",
        []
    )

    lines = [
        "VERA Knowledge Graph:",
        f"- Nodes: {len(nodes)}",
        f"- Relations: {len(edges)}"
    ]

    if edges:

        lines.append(
            "\nالعلاقات:"
        )

        for edge in edges[-20:]:

            lines.append(
                f"• {edge['source']} "
                f"--{edge['relation']}--> "
                f"{edge['target']}"
            )

    return "\n".join(lines)


def audit_knowledge_graph(repair=False):
    """Audit graph structure; optional repair is limited to safe structural fixes."""
    import copy
    original = copy.deepcopy(KNOWLEDGE)
    nodes = KNOWLEDGE.setdefault("nodes", [])
    edges = KNOWLEDGE.setdefault("edges", [])
    issues = []
    node_names = set()
    cleaned_nodes = []
    duplicate_nodes = 0
    blank_nodes = 0

    for node in nodes:
        if not isinstance(node, dict) or not str(node.get("name", "")).strip():
            blank_nodes += 1
            continue
        key = normalize_text(node.get("name", ""))
        if key in node_names:
            duplicate_nodes += 1
            continue
        node_names.add(key)
        cleaned_nodes.append(node)

    edge_keys = set()
    cleaned_edges = []
    duplicate_edges = 0
    blank_edges = 0
    missing_names = []
    for edge in edges:
        if not isinstance(edge, dict):
            blank_edges += 1
            continue
        source = str(edge.get("source", "")).strip()
        relation = str(edge.get("relation", "")).strip()
        target = str(edge.get("target", "")).strip()
        if not source or not relation or not target:
            blank_edges += 1
            continue
        key = (normalize_text(source), normalize_text(relation), normalize_text(target))
        if key in edge_keys:
            duplicate_edges += 1
            continue
        edge_keys.add(key)
        cleaned_edges.append(edge)
        for name in (source, target):
            if normalize_text(name) not in node_names:
                missing_names.append(name)
                node_names.add(normalize_text(name))

    if duplicate_nodes: issues.append(f"عُقد مكررة: {duplicate_nodes}")
    if blank_nodes: issues.append(f"عُقد فارغة/غير صالحة: {blank_nodes}")
    if duplicate_edges: issues.append(f"علاقات مكررة: {duplicate_edges}")
    if blank_edges: issues.append(f"علاقات فارغة/غير صالحة: {blank_edges}")
    if missing_names: issues.append(f"أطراف علاقات غير موجودة كعُقد: {len(set(normalize_text(x) for x in missing_names))}")

    if not repair:
        if not issues:
            return f"فحص الجراف: سليم بنيويًا. العُقد: {len(nodes)}، العلاقات: {len(edges)}."
        return "فحص الجراف:\n- " + "\n- ".join(issues) + "\nاكتب: اصلح الجراف لإصلاح التكرار والعناصر غير الصالحة وإضافة العُقد الناقصة."

    fixed_nodes = list(cleaned_nodes)
    fixed_name_keys = {normalize_text(n.get("name", "")) for n in fixed_nodes}
    for name in missing_names:
        key = normalize_text(name)
        if key and key not in fixed_name_keys:
            fixed_nodes.append({"id": str(uuid.uuid4()), "name": name, "type": "concept", "created_at": timestamp()})
            fixed_name_keys.add(key)

    KNOWLEDGE["nodes"] = fixed_nodes
    KNOWLEDGE["edges"] = cleaned_edges
    KNOWLEDGE["version"] = max(1, int(KNOWLEDGE.get("version", 1) or 1))
    if not save_graph():
        KNOWLEDGE.clear()
        KNOWLEDGE.update(original)
        return "فشل حفظ إصلاح الجراف؛ رجعت البيانات داخل الذاكرة للحالة السابقة."

    changes = duplicate_nodes + blank_nodes + duplicate_edges + blank_edges + len(set(normalize_text(x) for x in missing_names))
    if not changes:
        return f"الجراف سليم؛ مفيش إصلاحات مطلوبة. العُقد: {len(fixed_nodes)}، العلاقات: {len(cleaned_edges)}."
    return f"تم إصلاح الجراف بنجاح. الإصلاحات البنيوية: {changes}. العُقد الآن: {len(fixed_nodes)}، العلاقات: {len(cleaned_edges)}."


def knowledge_command(text):

    clean = normalize_text(text)

    if clean in ["افحص الجراف", "فحص الجراف", "دقق الجراف", "audit graph"]:
        return audit_knowledge_graph(False)

    if clean in ["اصلح الجراف", "اصلاح الجراف", "نظف الجراف", "repair graph"]:
        return audit_knowledge_graph(True)

    if clean in [
        "اعرض الجراف",
        "اعرض العلاقات",
        "knowledge graph",
        "graph"
    ]:

        return graph_summary()

    match = re.match(
        r"^اربط\s+(.+?)\s+ب\s+(.+?)\s+على انه\s+(.+)$",
        clean
    )

    if match:

        source = match.group(1)
        target = match.group(2)
        relation = match.group(3)

        if add_relation(
            source,
            relation,
            target
        ):

            return (
                "تمام، سجلت العلاقة:\n"
                f"{source} --{relation}--> {target}"
            )

        return "العلاقة موجودة بالفعل."

    return None


# Populate graph from existing explicit memory when VERA starts.
# This is additive: it does not delete existing nodes or relationships.
sync_memory_to_graph()


# =========================================================
# MEMORY COMMAND
# =========================================================

def audit_memory(repair=False):
    """Check memory schema and duplicate active entries without deleting timeline history."""
    import copy
    original = copy.deepcopy(MEMORY)
    issues = []
    profile = MEMORY.get("profile")
    if not isinstance(profile, dict):
        issues.append("قسم profile ليس كائنًا")
    invalid_categories = []
    duplicate_count = 0
    invalid_items = 0
    for category in CATEGORIES:
        if category == "profile":
            continue
        value = MEMORY.get(category)
        if not isinstance(value, list):
            invalid_categories.append(category)
            continue
        seen = set()
        for item in value:
            if not isinstance(item, dict) or not str(item.get("text", "")).strip():
                invalid_items += 1
                continue
            key = normalize_text(item.get("text", ""))
            # Timeline/events are historical records, so identical events are not collapsed.
            if category != "events" and key in seen:
                duplicate_count += 1
            seen.add(key)

    if invalid_categories:
        issues.append("أقسام ليست قوائم: " + ", ".join(invalid_categories))
    if invalid_items:
        issues.append(f"عناصر فارغة/غير صالحة: {invalid_items}")
    if duplicate_count:
        issues.append(f"عناصر مكررة في الذاكرة الحالية: {duplicate_count}")

    if not repair:
        if not issues:
            return "فحص الذاكرة: البنية سليمة. تم الحفاظ على سجل الأحداث التاريخي كما هو."
        return "فحص الذاكرة:\n- " + "\n- ".join(issues) + "\nاكتب: اصلح الذاكرة لإصلاح البنية والتكرار، مع الاحتفاظ بسجل الأحداث."

    fixed = {"version": 3}
    profile = MEMORY.get("profile", {})
    fixed["profile"] = profile if isinstance(profile, dict) else {}
    for category in CATEGORIES:
        if category == "profile":
            continue
        items = MEMORY.get(category, [])
        if not isinstance(items, list):
            items = []
        valid = []
        seen = set()
        for item in items:
            if not isinstance(item, dict) or not str(item.get("text", "")).strip():
                continue
            key = normalize_text(item.get("text", ""))
            if category != "events" and key in seen:
                continue
            seen.add(key)
            valid.append(item)
        fixed[category] = valid

    MEMORY.clear()
    MEMORY.update(fixed)
    if not safe_json_save(MEMORY_V2_FILE, MEMORY):
        MEMORY.clear()
        MEMORY.update(original)
        return "فشل حفظ إصلاح الذاكرة؛ رجعت البيانات داخل الذاكرة للحالة السابقة."

    remaining = audit_memory(False)
    if remaining.startswith("فحص الذاكرة: البنية سليمة"):
        return "تم إصلاح بنية الذاكرة بنجاح. سجل الأحداث التاريخي لم يتم دمجه أو حذفه."
    return "تمت محاولة إصلاح الذاكرة، لكن ما زالت هناك ملاحظات:\n" + remaining


def memory_command(text):

    clean = normalize_text(text)

    if clean in ["افحص الذاكره", "فحص الذاكره", "دقق الذاكره", "audit memory"]:
        return audit_memory(False)

    if clean in ["اصلح الذاكره", "اصلاح الذاكره", "نظف الذاكره", "repair memory"]:
        return audit_memory(True)

    timeline_patterns = [
        r"^تاريخ المعلومه\s*(.*)$",
        r"^تاريخ\s*(.*)$",
        r"^سجل الذاكره\s*(.*)$",
        r"^timeline\s*(.*)$",
        r"^memory timeline\s*(.*)$",
        r"^memory history\s*(.*)$"
    ]

    for pattern in timeline_patterns:

        match = re.match(
            pattern,
            clean
        )

        if match:

            return memory_timeline(
                match.group(1).strip()
            )

    if clean in [
        "اعرض الذاكره",
        "اعرض كل الذاكره",
        "الذاكره",
        "ذاكرتي",
        "memory",
        "show memory"
    ]:

        return memory_summary()

    if clean in [
        "ملخص الذاكره",
        "memory summary"
    ]:

        return memory_summary()

    if clean in [
        "امسح الذاكره",
        "clear memory"
    ]:

        return clear_memory()

    favorite_color_questions = {
        "لوني المفضل ايه",
        "ايه لوني المفضل",
        "ما هو لوني المفضل",
        "ما لوني المفضل",
        "what is my favorite color",
        "whats my favorite color",
        "my favorite color"
    }

    if clean in favorite_color_questions:
        value = get_keyed_memory("favorite_color")
        if value:
            color = re.sub(
                r"^(لوني المفضل|my favorite color|favorite color)\s*",
                "",
                value,
                flags=re.IGNORECASE
            ).strip()
            return f"من ذاكرتي الحالية: لونك المفضل {color}."
        return "مش عندي لون مفضل محفوظ حاليًا، ومش هخمن."

    patterns = [

        (r"^اسمي\s+(.+)$", "profile"),
        (r"^انا اسمي\s+(.+)$", "profile"),
        (r"^my name is\s+(.+)$", "profile"),

        (r"^افتكر اني بحب\s+(.+)$", "likes"),
        (r"^افتكر اني احب\s+(.+)$", "likes"),
        (r"^بحب\s+(.+)$", "likes"),
        (r"^i like\s+(.+)$", "likes"),

        (r"^مش بحب\s+(.+)$", "dislikes"),
        (r"^افتكر اني مش بحب\s+(.+)$", "dislikes"),

        (r"^هدفي\s+(.+)$", "goals"),
        (r"^هدفي اني\s+(.+)$", "goals"),
        (r"^هدفي ان\s+(.+)$", "goals"),
        (r"^my goal is\s+(.+)$", "goals"),

        (r"^مشروعي\s+(.+)$", "projects"),
        (r"^مشروعي هو\s+(.+)$", "projects"),

        (r"^افتكر ان\s+(.+)$", "facts"),
        (r"^افتكر اني\s+(.+)$", "facts")
    ]

    for pattern, category in patterns:

        match = re.match(
            pattern,
            clean
        )

        if match:

            value = match.group(1).strip()

            if not value:
                return None

            changed = add_memory(
                category,
                value
            )

            if not changed:

                return (
                    "المعلومة دي موجودة عندي بالفعل."
                )

            labels = {
                "profile": "اسمك",
                "likes": "اللي بتحبه",
                "dislikes": "إنك مش بتحب",
                "goals": "هدفك",
                "projects": "مشروعك",
                "facts": "المعلومة"
            }

            return (
                "تمام، حفظت "
                + labels.get(
                    category,
                    "المعلومة"
                )
                + ": "
                + value
            )

    if clean in [
        "اسمي اي",
        "ايه اسمي",
        "ما اسمي",
        "what is my name"
    ]:

        name = get_name()

        if name:

            return (
                f"من ذاكرتي: اسمك {name}."
            )

        return (
            "مش عارف اسمك لسه، ومش هخمن."
        )

    if clean in [
        "ايه اهدافي",
        "اي اهدافي",
        "ما هي اهدافي",
        "اهدافي",
        "my goals"
    ]:

        goals = MEMORY.get(
            "goals",
            []
        )

        if not goals:

            return (
                "مش عندي أهداف محفوظة."
            )

        return (
            "من ذاكرتي، أهدافك:\n"
            + "\n".join(
                f"• {item['text']}"
                for item in goals
            )
        )

    if (
        clean.startswith("فاكر ")
        or clean.startswith("فاكر")
        or clean.startswith("do you remember ")
        or clean.startswith("remember ")
    ):

        query = re.sub(
            r"^(فاكر|do you remember|remember)\s*",
            "",
            clean
        ).strip()

        results = search_memory(
            query
        )

        if results:

            top_score = results[0]["score"]

            conflicts = [
                item
                for item in results
                if item["score"] >= top_score - 0.08
            ]

            unique_texts = []

            for item in conflicts:

                if item["text"] not in unique_texts:

                    unique_texts.append(
                        item["text"]
                    )

            if len(unique_texts) > 1:

                return (
                    "⚠️ لقيت تعارض في ذاكرتي:\n"
                    + "\n".join(
                        f"• {value}"
                        for value in unique_texts
                    )
                    + "\nمش هختار واحدة من عندي."
                )

            return (
                "من ذاكرتي: "
                + results[0]["text"]
            )

        return (
            "مش لاقي المعلومة دي في ذاكرتي، "
            "ومش هخمن."
        )

    return None


def sync_old_memory():

    lines = []

    name = get_name()

    if name:
        lines.append(
            f"Name: {name}"
        )

    for item in MEMORY.get(
        "likes",
        []
    ):

        lines.append(
            f"Likes: {item['text']}"
        )

    for item in MEMORY.get(
        "goals",
        []
    ):

        lines.append(
            f"Goals: {item['text']}"
        )

    for item in MEMORY.get(
        "facts",
        []
    ):

        lines.append(
            f"Fact: {item['text']}"
        )

    try:

        with open(
            MEMORY_FILE,
            "w",
            encoding="utf-8"
        ) as f:

            f.write(
                "\n".join(lines)
            )

    except Exception:
        pass


# =========================================================
# REASONING ENGINE
# =========================================================

def classify_problem(text):

    clean = normalize_text(text)

    if any(
        word in clean
        for word in [
            "ليه",
            "لماذا",
            "ازاي",
            "كيف",
            "احسب",
            "حل",
            "why",
            "how",
            "solve",
            "calculate"
        ]
    ):

        return "reasoning"

    if "؟" in text or "?" in text:

        return "question"

    return "statement"


def reasoning_engine(text):

    kind = classify_problem(text)

    tokens = normalize_text(text).split()

    complexity = (
        "low"
        if len(tokens) <= 5
        else "medium"
        if len(tokens) <= 15
        else "high"
    )

    return {
        "type": kind,
        "complexity": complexity,
        "tokens": len(tokens),
        "requires_external_verification": False
    }


def reasoning_command(text):

    clean = normalize_text(text)

    prefixes = [
        "حلل:",
        "حلل",
        "reason:",
        "reason",
        "reasoning:",
        "reasoning"
    ]

    target = None

    for prefix in prefixes:
        if clean.startswith(prefix):
            target = clean[len(prefix):].strip()
            break

    if target is None:
        if clean in [
            "حلل السؤال",
            "حلل ده",
            "حلل الجملة",
            "reasoning status"
        ]:
            target = clean
        else:
            return None

    if not target:
        target = text

    result = reasoning_engine(target)

    return (
        "VERA Reasoning Engine:\n"
        f"- النوع: {result['type']}\n"
        f"- التعقيد: {result['complexity']}\n"
        f"- عدد الكلمات: {result['tokens']}\n"
        "- يحتاج تحقق خارجي: لا"
    )


# =========================================================
# CALCULATOR
# =========================================================

def calculator(text):

    original = convert_arabic_digits(text)
    clean = normalize_text(original)

    prefixes = [
        "ممكن تحسبلي",
        "ممكن تحسب لي",
        "ممكن تحسب",
        "احسبلي",
        "احسب لي",
        "احسب",
        "حساب",
        "calculate for me",
        "calculate",
        "calc"
    ]

    for prefix in prefixes:

        if clean.startswith(prefix):

            clean = clean[
                len(prefix):
            ].strip()

            break

    replacements = {
        "ضرب": "*",
        "قسمة": "/",
        "على": "/",
        "زائد": "+",
        "جمع": "+",
        "ناقص": "-",
        "طرح": "-",
        "×": "*",
        "÷": "/"
    }

    for word, symbol in replacements.items():

        clean = clean.replace(
            word,
            symbol
        )

    clean = clean.replace(
        "؟",
        ""
    ).strip()

    if not re.search(
        r"\d",
        clean
    ):
        return None

    if not re.fullmatch(
        r"[0-9+\-*/%().\s]+",
        clean
    ):
        return None

    try:

        result = eval(
            clean,
            {
                "__builtins__": {}
            },
            {}
        )

        if isinstance(
            result,
            (int, float)
        ):

            if (
                isinstance(result, float)
                and result.is_integer()
            ):

                result = int(result)

            return str(result)

    except Exception:
        return None

    return None


# =========================================================
# TIME / DATE
# =========================================================

def time_command():

    return (
        "الوقت الحالي: "
        + datetime.now().strftime(
            "%H:%M:%S"
        )
    )


def date_command():

    return (
        "تاريخ النهارده: "
        + datetime.now().strftime(
            "%Y-%m-%d"
        )
    )


# =========================================================
# CONTEXT
# =========================================================

def save_conversation(
    user,
    response
):

    try:

        with open(
            CONVERSATION_FILE,
            "a",
            encoding="utf-8"
        ) as f:

            f.write(
                f"[{timestamp()}]\n"
            )

            f.write(
                f"USER: {user}\n"
            )

            f.write(
                f"VERA: {response}\n\n"
            )

    except Exception:
        pass


def previous_user_message():

    if not CONVERSATION_FILE.exists():
        return None

    try:

        with open(
            CONVERSATION_FILE,
            "r",
            encoding="utf-8"
        ) as f:

            content = f.read()

        messages = re.findall(
            r"USER:\s*(.+)",
            content
        )

        if len(messages) >= 2:

            return messages[-2].strip()

    except Exception:
        pass

    return None


def context_command(text):

    clean = normalize_text(text)

    if clean in [
        "what did i just say",
        "what did i say",
        "انا قلت اي",
        "انا قلت ايه",
        "قلت اي",
        "قلت ايه",
        "انت قلت اي",
        "انت قلت ايه"
    ]:

        previous = previous_user_message()

        if previous:

            return (
                f"إنت قلت: {previous}"
            )

        return (
            "مش عندي رسالة سابقة."
        )

    return None


# =========================================================
# PLANNING
# =========================================================

def read_plan():

    if not PLAN_FILE.exists():
        return []

    try:

        with open(
            PLAN_FILE,
            "r",
            encoding="utf-8"
        ) as f:

            return [
                line.rstrip()
                for line in f
            ]

    except Exception:
        return []


def write_plan(lines):
    """Atomically replace the text plan to reduce risk from interrupted writes."""
    temp_path = PLAN_FILE.with_name(PLAN_FILE.name + ".tmp")
    try:
        with open(temp_path, "w", encoding="utf-8") as f:
            f.write("\n".join(str(line) for line in lines))
            f.flush()
            os.fsync(f.fileno())
        os.replace(temp_path, PLAN_FILE)
        return True
    except Exception:
        try:
            temp_path.unlink(missing_ok=True)
        except Exception:
            pass
        return False


def create_plan(goal):

    steps = [
        "حدد الهدف والنتيجة المطلوبة",
        "قسم الهدف إلى مهام صغيرة",
        "ابدأ بأول مهمة",
        "راجع النتيجة",
        "كمل المهمة التالية",
        "راجع التقدم وعدل الخطة إذا لزم"
    ]

    lines = [
        f"GOAL: {goal}",
        "STATUS: ACTIVE",
        "CURRENT: 1"
    ]

    for i, step in enumerate(
        steps,
        1
    ):

        lines.append(
            f"STEP {i}: {step} | PENDING"
        )

    if not write_plan(lines):
        return "مقدرتش أحفظ الخطة على الجهاز؛ ما أقدرش أقول إنها اتعملت."

    return (
        "تمام. أنشأت خطة لهدفك:\n"
        f"{goal}\n\n"
        + "\n".join(
            f"{i}. {step}"
            for i, step in enumerate(
                steps,
                1
            )
        )
        + "\n\nالمهمة الحالية: 1"
    )


def get_plan():

    lines = read_plan()

    if not lines:
        return None

    goal = ""
    status = ""
    current = 0
    steps = []

    for line in lines:

        if line.startswith("GOAL:"):

            goal = line[
                5:
            ].strip()

        elif line.startswith("STATUS:"):

            status = line[
                7:
            ].strip()

        elif line.startswith("CURRENT:"):

            try:

                current = int(
                    line[
                        8:
                    ].strip()
                )

            except Exception:

                current = 0

        elif line.startswith("STEP"):

            match = re.match(
                r"STEP\s+(\d+):\s+(.+?)\s+\|\s+(.+)",
                line
            )

            if match:

                steps.append({
                    "number": int(
                        match.group(1)
                    ),
                    "text": match.group(2),
                    "status": match.group(3)
                })

    return {
        "goal": goal,
        "status": status,
        "current": current,
        "steps": steps
    }


def complete_current_step():
    """Mark the current pending step done and safely advance the plan."""
    lines = read_plan()
    if not lines:
        return "مفيش خطة حالية."

    current = None
    for line in lines:
        if line.startswith("CURRENT:"):
            try:
                current = int(line.split(":", 1)[1].strip())
            except (TypeError, ValueError):
                return "الخطة غير صالحة: رقم المهمة الحالية مش مفهوم."

    if current is None:
        return "الخطة غير صالحة: رقم المهمة الحالية مش موجود."

    step_index = None
    step_status = None
    for i, line in enumerate(lines):
        match = re.match(r"^STEP\s+(\d+):.*\|\s*(.+?)\s*$", line)
        if match and int(match.group(1)) == current:
            step_index = i
            step_status = match.group(2).strip().upper()
            break

    if step_index is None:
        return f"المهمة الحالية رقم {current} مش موجودة في الخطة."

    if step_status == "DONE":
        return f"المهمة {current} مكتملة بالفعل؛ ما غيرتش الخطة عشان ما نتخطّاش مهام."

    if step_status != "PENDING":
        return f"حالة المهمة {current} غير معروفة ({step_status})، وما غيرتش الخطة."

    # Change only the exact current step's status.
    lines[step_index] = re.sub(r"\|\s*PENDING\s*$", "| DONE", lines[step_index], count=1)

    pending_steps = []
    all_steps = []
    for line in lines:
        match = re.match(r"^STEP\s+(\d+):.*\|\s*(.+?)\s*$", line)
        if match:
            number = int(match.group(1))
            status = match.group(2).strip().upper()
            all_steps.append(number)
            if status == "PENDING":
                pending_steps.append(number)

    if not all_steps:
        return "الخطة مفيهاش مهام صالحة."

    next_pending = next((number for number in pending_steps if number > current), None)
    if next_pending is None and pending_steps:
        next_pending = pending_steps[0]

    if next_pending is None:
        for i, line in enumerate(lines):
            if line.startswith("STATUS:"):
                lines[i] = "STATUS: COMPLETED"
        # Keep CURRENT on the last actual step rather than creating an invalid step number.
        current_line_value = max(all_steps)
        for i, line in enumerate(lines):
            if line.startswith("CURRENT:"):
                lines[i] = f"CURRENT: {current_line_value}"
        if not write_plan(lines):
            return "حالة المهمة اتجهزت للتحديث، لكن مقدرتش أحفظ الخطة. حاول تاني."
        return "🎉 خلصنا كل مهام الخطة. الهدف مكتمل."

    for i, line in enumerate(lines):
        if line.startswith("CURRENT:"):
            lines[i] = f"CURRENT: {next_pending}"
        elif line.startswith("STATUS:") and line.split(":", 1)[1].strip().upper() == "COMPLETED":
            lines[i] = "STATUS: ACTIVE"

    if not write_plan(lines):
        return "مقدرتش أحفظ تحديث الخطة؛ مفيش تأكيد إن المهمة اتسجلت كمكتملة."

    return f"تمام، خلصنا المهمة {current}.\nالمهمة الحالية: {next_pending}"


def plan_display():

    info = get_plan()

    if not info:
        return "مفيش خطة حالية."

    output = [
        "VERA Current Plan:",
        f"- GOAL: {info['goal']}",
        f"- STATUS: {info['status']}",
        f"- CURRENT: {info['current']}"
    ]

    for step in info["steps"]:

        output.append(
            f"- STEP {step['number']}: "
            f"{step['text']} | {step['status']}"
        )

    return "\n".join(output)


def evaluate_plan():

    info = get_plan()

    if not info:
        return "مفيش خطة أقدر أقيمها."

    steps = info["steps"]

    if not steps:
        return "الخطة مفيهاش مهام."

    done = sum(
        1
        for step in steps
        if step["status"] == "DONE"
    )

    total = len(steps)

    progress = int(
        done / total * 100
    )

    return (
        "VERA Self-Evaluation:\n"
        f"- الحالة: {info['status']}\n"
        f"- التقدم: {progress}%\n"
        f"- المكتمل: {done}/{total}\n"
        f"- المتبقي: {total - done}\n"
        f"- المهمة الحالية: {info['current']}"
    )


def adaptive_plan():

    info = get_plan()

    if not info:
        return "مفيش خطة أقدر أعدلها."

    steps = info["steps"]

    if not steps:
        return "الخطة مفيهاش مهام."

    done = sum(
        1
        for step in steps
        if step["status"] == "DONE"
    )

    total = len(steps)

    progress = int(
        done / total * 100
    )

    if progress == 100:

        return (
            "تحليل الخطة:\n"
            "التقدم 100%.\n"
            "الخطة مكتملة."
        )

    if progress < 50:

        message = (
            "ركز على المهمة الحالية "
            "وما تفتحش مهام كثيرة مرة واحدة."
        )

    else:

        message = (
            "التقدم كويس، كمل المهام المتبقية "
            "واعمل مراجعة بعد كل مرحلة."
        )

    return (
        "VERA Adaptive Planning:\n"
        f"- التقدم: {progress}%\n"
        f"- المهمة الحالية: {info['current']}\n"
        f"- التوصية: {message}"
    )


def audit_plan(repair=False):
    """Inspect plan structure; repairs only normalize statuses and CURRENT/STATUS consistency."""
    lines = read_plan()
    if not lines:
        return "فحص الخطة: مفيش خطة محفوظة حاليًا."
    info = get_plan()
    issues = []
    if not info or not info.get("goal"):
        issues.append("الهدف مفقود")
    if not info or not info.get("steps"):
        issues.append("مفيش خطوات صالحة")
    steps = info.get("steps", []) if info else []
    numbers = [step.get("number") for step in steps]
    if len(numbers) != len(set(numbers)):
        issues.append("أرقام خطوات مكررة")
    valid_statuses = {"PENDING", "DONE"}
    if any(str(step.get("status", "")).upper() not in valid_statuses for step in steps):
        issues.append("حالة خطوة غير معروفة")
    if info and steps and info.get("current") not in numbers:
        issues.append("رقم المهمة الحالية مش موجود")
    pending = [step["number"] for step in steps if str(step.get("status", "")).upper() == "PENDING"]
    if info and steps:
        expected_status = "ACTIVE" if pending else "COMPLETED"
        if str(info.get("status", "")).upper() != expected_status:
            issues.append(f"حالة الخطة لا تتوافق مع المهام؛ المتوقع {expected_status}")

    if not repair:
        if not issues:
            return f"فحص الخطة: سليمة بنيويًا. عدد المهام: {len(steps)}، المتبقي: {len(pending)}."
        return "فحص الخطة:\n- " + "\n- ".join(issues) + "\nاكتب: اصلح الخطة لمراجعة الحالات ورقم المهمة الحالية."

    # Do not guess missing goals or invent steps; repair only safe state consistency.
    if not info or not steps or not info.get("goal"):
        return "مش هعدّل الخطة تلقائيًا لأن الهدف أو الخطوات الأساسية ناقصة. راجعها يدويًا أو أنشئ خطة جديدة."
    if len(numbers) != len(set(numbers)):
        return "فيه أرقام خطوات مكررة؛ الإصلاح التلقائي متوقف عشان ما يغيّرش ترتيب مهامك بشكل تخميني."
    if any(str(step.get("status", "")).upper() not in valid_statuses for step in steps):
        return "فيه حالة مهمة غير معروفة؛ الإصلاح التلقائي متوقف عشان ما نخمنش إذا كانت المهمة خلصت ولا لأ."

    pending = [step["number"] for step in steps if str(step.get("status", "")).upper() == "PENDING"]
    if pending:
        current = info.get("current") if info.get("current") in numbers and info.get("current") in pending else pending[0]
        status = "ACTIVE"
    else:
        current = max(numbers)
        status = "COMPLETED"

    output = []
    saw_current = False
    saw_status = False
    for line in lines:
        if line.startswith("CURRENT:"):
            output.append(f"CURRENT: {current}")
            saw_current = True
        elif line.startswith("STATUS:"):
            output.append(f"STATUS: {status}")
            saw_status = True
        else:
            output.append(line)
    if not saw_current:
        output.insert(2, f"CURRENT: {current}")
    if not saw_status:
        output.insert(1, f"STATUS: {status}")
    if not write_plan(output):
        return "فشل حفظ إصلاح الخطة؛ ما أقدرش أؤكد إنه اتطبق."
    return f"تم ضبط حالة الخطة ورقم المهمة الحالية. الحالة: {status}، المهمة الحالية: {current}."


def planning_command(text):

    clean = normalize_text(text)

    if clean in ["افحص الخطه", "فحص الخطه", "دقق الخطه", "audit plan"]:
        return audit_plan(False)

    if clean in ["اصلح الخطه", "اصلاح الخطه", "راجع الخطه", "repair plan"]:
        return audit_plan(True)

    if clean in [
        "خطتي",
        "الخطة",
        "اعرض الخطة",
        "ايه خطتي",
        "my plan",
        "show plan"
    ]:

        return plan_display()

    if clean in [
        # normalize_text converts ة to ه, so these Arabic aliases must
        # use the normalized spelling to actually match.
        "خلصت المهمه",
        "انجزت المهمه",
        "done",
        "complete task"
    ]:

        return complete_current_step()

    if clean in [
        "قيم الخطة",
        "قيم الخطه",  # normalize_text converts ة to ه
        "قيم خطتي",
        "قيم التقدم",
        "evaluate plan"
    ]:

        return evaluate_plan()

    if clean in [
        "عدل الخطة",
        "عدل الخطه",
        "طور الخطة",
        "طور الخطه",
        "حسن الخطة",
        "حسن الخطه",
        "تكيف مع التقدم",
        "adaptive plan",
        "adapt plan"
    ]:

        return adaptive_plan()

    if clean in [
        "امسح الخطة",
        "امسح الخطه",
        "clear plan"
    ]:

        if PLAN_FILE.exists():

            try:
                PLAN_FILE.unlink()
            except Exception:
                pass

        return "تمام، مسحت الخطة الحالية."

    prefixes = [
        "خططلي ",
        "خطط لي ",
        "اعمللي خطة ",
        "اعمل لي خطة ",
        "اعمل خطة ",
        "plan "
    ]

    for prefix in prefixes:

        if clean.startswith(prefix):

            goal = text[
                len(prefix):
            ].strip()

            if goal:

                return create_plan(
                    goal
                )

    return None


# =========================================================
# SELF EVALUATION
# =========================================================

def save_self_evaluation(
    user,
    response,
    confidence,
    category
):

    data = safe_json_load(
        SELF_EVAL_FILE,
        {
            "version": 1,
            "evaluations": []
        }
    )

    data["evaluations"].append({
        "time": timestamp(),
        "input": user,
        "response": response,
        "confidence": confidence,
        "category": category
    })

    data["evaluations"] = data[
        "evaluations"
    ][-100:]

    safe_json_save(
        SELF_EVAL_FILE,
        data
    )


def confidence_for_response(
    response,
    category
):
    # Internal heuristic scores, not calibrated probabilities.

    if response == unknown_response():
        return 0.0

    if category == "memory":
        return 0.95

    if category == "calculator":
        return 0.99

    if category == "identity":
        return 0.99

    if category == "planning":
        return 0.90

    if category == "truthfulness":
        return 0.95

    if category == "reasoning":
        return 0.70

    return 0.80


def self_status():

    data = safe_json_load(
        SELF_EVAL_FILE,
        {
            "version": 1,
            "evaluations": []
        }
    )

    evaluations = data.get(
        "evaluations",
        []
    )

    if not evaluations:

        return (
            "VERA Self-Evaluation:\n"
            "لسه مفيش سجل تقييمات."
        )

    recent = evaluations[-20:]

    average = sum(
        item.get(
            "confidence",
            0
        )
        for item in recent
    ) / len(recent)

    return (
        "VERA Self-Evaluation:\n"
        f"- التقييمات: {len(evaluations)}\n"
        f"- متوسط الثقة الأخيرة: "
        f"{average:.0%}\n"
        "- ملاحظة: الثقة الداخلية ليست إثباتًا للحقيقة."
    )


# =========================================================
# FILES
# =========================================================

def files_command():

    try:

        files = [
            item.name
            for item in BASE_DIR.iterdir()
            if item.is_file()
        ]

        if not files:
            return "مفيش ملفات."

        return (
            "الملفات:\n"
            + "\n".join(
                f"• {name}"
                for name in sorted(files)
            )
        )

    except Exception:

        return (
            "مش قادر أقرأ الملفات حاليًا."
        )


# =========================================================
# PROFILE
# =========================================================

def profile_command(text):

    clean = normalize_text(text)

    if clean in [
        "profile",
        "بروفايل",
        "ملفي",
        "ملفي الشخصي"
    ]:

        return (
            "VERA Profile:\n"
            f"- Name: {get_name() or 'غير محفوظ'}\n"
            f"- Likes: {len(MEMORY['likes'])}\n"
            f"- Goals: {len(MEMORY['goals'])}\n"
            f"- Projects: {len(MEMORY['projects'])}\n"
            f"- Facts: {len(MEMORY['facts'])}\n"
            f"- Timeline Events: {len(MEMORY['events'])}\n"
            f"- Knowledge Nodes: {len(KNOWLEDGE['nodes'])}\n"
            f"- Knowledge Relations: {len(KNOWLEDGE['edges'])}"
        )

    return None


# =========================================================
# GENERAL COMMANDS
# =========================================================

def greeting(text):

    clean = normalize_text(text)

    if clean in [
        "hello",
        "hi",
        "hey",
        "سلام",
        "هاي",
        "اهلا",
        "اهلا بيك",
        "صباح الخير",
        "مساء الخير"
    ]:

        name = get_name()

        if name:

            return (
                f"أهلا {name} 👋 أنا VERA 2.2."
            )

        return (
            "أهلا 👋 أنا VERA 2.2."
        )

    return None


def about_command(text):

    clean = normalize_text(text)

    if clean in [
        "about",
        "عن فيرا",
        "من انت",
        "من انتي",
        "who are you"
    ]:

        return (
            "أنا VERA 2.2.\n"
            f"Version: {VERSION}\n"
            "Local Memory: Enabled (JSON/text files)\n"
            "Memory Timeline: Enabled (saved changes only)\n"
            "Memory Deduplication: Basic similarity checks\n"
            "Truthfulness Rules: Local response rules\n"
            "Knowledge Graph: Manual relations only\n"
            "Reasoning: Basic rule-based classification, not full AI reasoning\n"
            "Planning: Basic task checklist\n"
            "Self-Evaluation: Heuristic logging, not a measure of real accuracy\n"
            "Digital Identity: Local ID and code fingerprint\n"
            f"LLM/API: {ai_connection_status()}"
        )

    return None


def help_command(text):

    clean = normalize_text(text)

    if clean not in [
        "help",
        "مساعده",
        "المساعده",
        "الاوامر",
        "ايه الاوامر"
    ]:

        return None

    return (
        "أوامر VERA 2.2:\n\n"
        "• احسب ١٢٥ ضرب ٨\n"
        "• الساعة كام؟\n"
        "• النهارده كام؟\n"
        "• اعرض الذاكرة\n"
        "• افتكر اني بحب البرمجة\n"
        "• فاكر البرمجة؟\n"
        "• تاريخ لوني المفضل\n"
        "• ايه اهدافي؟\n"
        "• خططلي اني اتعلم Python\n"
        "• خطتي\n"
        "• خلصت المهمة\n"
        "• قيم الخطة\n"
        "• عدل الخطة\n"
        "• اعرض الجراف\n"
        "• بصمة فيرا\n"
        "• قواعد فيرا\n"
        "• حالة التقييم\n"
        "• احفظ تجربة: المشكلة | الحل\n"
        "• اعرض التجارب / ابحث في التجارب كلمة\n"
        "• افحص الجراف / اصلح الجراف\n"
        "• افحص الذاكرة / اصلح الذاكرة\n"
        "• افحص الخطة / اصلح الخطة\n"
        "• حالة النظام / اعمل نسخة احتياطية\n"
        "• تقرير فيرا (ملخص كل الأنظمة)\n"
        "• افحص المشروع / اعمل نسخة عمل\n"
        "• خطط تنفيذ: وصف المهمة\n"
        "• راجع نقديًا: وصف الفكرة\n"
        "• حالة وكيل التنفيذ\n"
        "• حالة الذكاء الاصطناعي\n"
        "• اعرض الملفات\n"
        "• profile\n"
        "• about\n"
        "• exit"
    )


# =========================================================
# EXPERIENCE / ERROR LEARNING (LOCAL, EXPLICIT, AUDITABLE)
# =========================================================

def load_learning_cases():
    data = safe_json_load(LEARNING_FILE, {"version": 1, "cases": []})
    if not isinstance(data, dict):
        data = {"version": 1, "cases": []}
    cases = data.get("cases", [])
    if not isinstance(cases, list):
        cases = []
    return {"version": 1, "cases": cases}


def save_learning_cases(data):
    return safe_json_save(LEARNING_FILE, data)


def record_learning_case(problem, solution):
    problem = str(problem).strip()
    solution = str(solution).strip()
    if len(problem) < 3 or len(solution) < 2:
        return "اكتب المشكلة والحل بوضوح. مثال: احفظ تجربة: أمر لا يعمل | أضف الاسم المطبع للأمر في قائمة الأوامر."

    data = load_learning_cases()
    problem_key = normalize_text(problem)
    solution_key = normalize_text(solution)
    for case in data["cases"]:
        if normalize_text(case.get("problem", "")) == problem_key and normalize_text(case.get("solution", "")) == solution_key:
            return "التجربة دي محفوظة بالفعل؛ مش هكررها."

    data["cases"].append({
        "id": uuid.uuid4().hex[:10],
        "created_at": timestamp(),
        "problem": problem,
        "solution": solution,
        "uses": 0,
        "source": "user_confirmed"
    })
    if not save_learning_cases(data):
        return "معرفتش أحفظ التجربة على الجهاز؛ مفيش ادعاء إنها اتحفظت."
    return f"حفظت التجربة بنجاح. إجمالي التجارب المحفوظة: {len(data['cases'])}.\nملاحظة: دي خبرة محفوظة بمراجعتك، مش تعلّم تلقائي مضمون."


def learning_command(text):
    clean = normalize_text(text)
    raw = str(text).strip()

    prefixes = ["احفظ تجربه:", "احفظ تجربة:", "سجل تجربه:", "سجل تجربة:", "تعلم من الخطا:", "تعلم من الخطأ:", "save lesson:"]
    for prefix in prefixes:
        if clean.startswith(normalize_text(prefix)):
            # Split the original text so the saved Arabic wording remains readable.
            payload = raw.split(":", 1)[1].strip() if ":" in raw else ""
            if "|" not in payload:
                return "اكتبها بالشكل ده: احفظ تجربة: المشكلة | الحل"
            problem, solution = payload.split("|", 1)
            return record_learning_case(problem, solution)

    if clean in ["اعرض التجارب", "التجارب المحفوظه", "سجل الاخطاء", "اعرض سجل الاخطاء", "learning cases", "show lessons"]:
        data = load_learning_cases()
        cases = data["cases"]
        if not cases:
            return "لسه مفيش تجارب محفوظة. اكتب: احفظ تجربة: المشكلة | الحل"
        lines = [f"VERA Saved Experiences: {len(cases)}"]
        for i, case in enumerate(cases[-20:], 1):
            lines.append(f"{i}. المشكلة: {case.get('problem', '')}")
            lines.append(f"   الحل: {case.get('solution', '')}")
        return "\n".join(lines)

    search_prefixes = ["ابحث في التجارب ", "دور في التجارب ", "search lessons "]
    for prefix in search_prefixes:
        if clean.startswith(normalize_text(prefix)):
            query = raw[len(prefix):].strip()
            if not query:
                return "اكتب كلمة تبحث عنها بعد الأمر."
            q = normalize_text(query)
            matches = [c for c in load_learning_cases()["cases"] if q in normalize_text(c.get("problem", "") + " " + c.get("solution", ""))]
            if not matches:
                return "ملقيتش تجربة محفوظة مطابقة."
            lines = [f"لقيت {len(matches)} تجربة:"]
            for case in matches[-10:]:
                lines.append(f"المشكلة: {case.get('problem', '')}\nالحل المحفوظ: {case.get('solution', '')}")
            return "\n---\n".join(lines)

    return None


# =========================================================
# LOCAL SAFETY / BACKUPS / FILE HEALTH
# =========================================================

DATA_FILES = [
    MEMORY_FILE, MEMORY_V2_FILE, PLAN_FILE, IDENTITY_FILE,
    CONVERSATION_FILE, KNOWLEDGE_FILE, SELF_EVAL_FILE, LEARNING_FILE
]


def create_local_backup():
    """Copy current VERA data files into a timestamped folder next to the script."""
    import shutil
    backup_root = BASE_DIR / "backups"
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    destination = backup_root / f"vera_backup_{stamp}"
    try:
        destination.mkdir(parents=True, exist_ok=False)
        copied = []
        for source in DATA_FILES:
            if source.exists() and source.is_file():
                shutil.copy2(source, destination / source.name)
                copied.append(source.name)
        manifest = {
            "version": VERSION,
            "created_at": timestamp(),
            "files": copied,
            "note": "Local data backup; this does not back up the Python source code."
        }
        if not safe_json_save(destination / "backup_manifest.json", manifest):
            raise OSError("Could not save backup manifest")
        return f"تم إنشاء نسخة احتياطية محلية.\nالمجلد: {destination.name}\nالملفات المحفوظة: {len(copied)}\nالكود نفسه مش ضمن النسخة الاحتياطية؛ دي نسخة للبيانات فقط."
    except Exception as exc:
        try:
            if destination.exists():
                shutil.rmtree(destination)
        except Exception:
            pass
        return f"فشل إنشاء النسخة الاحتياطية: {type(exc).__name__}. البيانات الأصلية لم يتم حذفها."


def system_health_report():
    lines = [f"VERA System Health — {VERSION}"]
    healthy = 0
    warnings = 0
    for path in DATA_FILES:
        if not path.exists():
            lines.append(f"- {path.name}: غير موجود (قد يكون طبيعيًا لو الميزة لم تُستخدم بعد)")
            continue
        try:
            size = path.stat().st_size
            if path.suffix == ".json":
                with open(path, "r", encoding="utf-8") as f:
                    json.load(f)
            lines.append(f"- {path.name}: سليم، {size} bytes")
            healthy += 1
        except Exception:
            lines.append(f"- {path.name}: تحذير — الملف غير قابل للقراءة أو JSON غير صالح")
            warnings += 1
    lines.append(f"الملفات السليمة: {healthy} | التحذيرات: {warnings}")
    lines.append("ملاحظة: الفحص للسلامة البنيوية فقط، وليس تحققًا من صحة كل معلومة.")
    return "\n".join(lines)


def integrated_status_report():
    """One read-only overview of the major local VERA subsystems."""
    plan = get_plan()
    step_count = len(plan.get("steps", [])) if plan else 0
    done_count = sum(1 for step in (plan.get("steps", []) if plan else []) if str(step.get("status", "")).upper() == "DONE")
    pending_count = sum(1 for step in (plan.get("steps", []) if plan else []) if str(step.get("status", "")).upper() == "PENDING")
    memory_counts = {}
    for category in CATEGORIES:
        if category == "profile":
            continue
        value = MEMORY.get(category, [])
        memory_counts[category] = len(value) if isinstance(value, list) else 0
    evaluation_data = safe_json_load(SELF_EVAL_FILE, {"evaluations": []})
    evaluations = evaluation_data.get("evaluations", []) if isinstance(evaluation_data, dict) else []
    learning_count = len(load_learning_cases().get("cases", []))
    nodes = KNOWLEDGE.get("nodes", [])
    edges = KNOWLEDGE.get("edges", [])
    api_status = ai_connection_status()

    lines = [
        f"VERA Integrated Status — Version {VERSION}",
        "",
        "[CORE]",
        "- Memory: ACTIVE",
        "- Knowledge Graph: ACTIVE",
        "- Planning: " + ("ACTIVE" if plan else "NO PLAN SAVED"),
        "- Experience Log: ACTIVE",
        "- Self-Evaluation Log: ACTIVE",
        "",
        "[COUNTS]",
        f"- Profile name saved: {'YES' if get_name() else 'NO'}",
        f"- Memory items: {sum(memory_counts.values())} (likes {memory_counts.get('likes', 0)}, goals {memory_counts.get('goals', 0)}, facts {memory_counts.get('facts', 0)}, projects {memory_counts.get('projects', 0)})",
        f"- Knowledge Graph: {len(nodes)} nodes, {len(edges)} relations",
        f"- Saved experiences: {learning_count}",
        f"- Self-evaluation records: {len(evaluations)}",
        f"- Plan: {done_count}/{step_count} tasks done, {pending_count} pending" if plan else "- Plan: no saved plan",
        "",
        "[AI CONNECTION]",
        f"- {api_status}",
        "",
        "This report describes local component state; it does not prove factual accuracy or autonomous learning."
    ]
    return "\n".join(lines)


def integrated_command(text):
    clean = normalize_text(text)
    if clean in ["تقرير فيرا", "حاله فيرا", "حالة فيرا", "ملخص النظام", "حاله المشروع", "system report", "vera status"]:
        return integrated_status_report()
    return None


def safety_command(text):
    clean = normalize_text(text)
    if clean in ["اعمل نسخه احتياطيه", "اعمل نسخة احتياطية", "نسخه احتياطيه", "نسخة احتياطية", "backup", "create backup"]:
        return create_local_backup()
    if clean in ["حاله النظام", "حالة النظام", "افحص النظام", "فحص النظام", "system health", "health check"]:
        return system_health_report()
    return None




# =========================================================
# VERA 3.0 — LOCAL EVIDENCE RETRIEVAL CORE
# This is deterministic local retrieval, not a trained language model.
# =========================================================

# VERA 3.1 — multilingual local evidence retrieval with source aggregation.
# This remains deterministic retrieval, not an LLM and not a truth verifier.

_EVIDENCE_SYNONYMS = {
    "technology": "technology", "technologies": "technology", "tech": "technology",
    "التكنولوجيا": "technology", "تكنولوجيا": "technology", "تقنيه": "technology", "تقنيه": "technology",
    "business": "business", "businesses": "business", "commerce": "business",
    "تجاره": "business", "اعمال": "business", "بيزنس": "business",
    "artificial": "ai", "intelligence": "ai", "ai": "ai", "اى": "ai",
    "ذكاء": "ai", "اصطناعي": "ai", "اصطناعى": "ai", "الاصطناعي": "ai", "الاصطناعى": "ai",
    "goal": "goal", "goals": "goal", "هدف": "goal", "اهداف": "goal", "هدفي": "goal",
    "build": "build", "building": "build", "ابني": "build", "ابنى": "build", "بني": "build",
    "company": "company", "companies": "company", "شركه": "company", "شركة": "company", "الشركه": "company", "الشركة": "company",
    "زكاء": "ai", "ذكاء": "ai", "اصتناعي": "ai", "اصطناعي": "ai", "الاصتناعي": "ai", "الاصطناعي": "ai",
    "like": "like", "likes": "like", "احب": "like", "بحب": "like", "بحبش": "dislike",
}
_EVIDENCE_COMMAND_WORDS = {
    "استرجع", "ابحث", "في", "الذاكره", "عن", "مصادر", "الاجابه", "ماذا", "تعرف", "ما", "الذي", "تعرفه",
    "موضوع", "معلومات", "معلومه", "هات", "وريني", "اعرض", "اعرضلي", "لي", "عندي", "عندك",
    "retrieve", "search", "find", "show", "me", "about", "what", "know", "the", "my", "for"
}

def _canonical_evidence_token(token):
    token = normalize_text(token)
    return _EVIDENCE_SYNONYMS.get(token, token)

def _evidence_tokens(text):
    text = normalize_text(convert_arabic_digits(text))
    tokens = re.findall(r"[a-z0-9_]+|[\u0600-\u06FF]+", text)
    stop = {
        "ايه", "اي", "ماذا", "هو", "هي", "انا", "انت", "كان", "كانت", "مع", "هل", "ده", "دي", "دا",
        "المعلومات", "اللي", "عندي", "عندك", "the", "what", "about", "tell", "me", "my", "is", "are", "in", "on"
    }
    return [_canonical_evidence_token(t) for t in tokens
            if len(t) > 1 and t not in stop and t not in _EVIDENCE_COMMAND_WORDS]

def _evidence_identity(text):
    """Normalize repeated representations of the same saved statement."""
    value = normalize_text(text)
    # Graph edges often wrap a fact as: person has_fact <fact>.
    value = re.sub(r"^(?:\w+\s+)?(?:has_fact|likes|has_goal|related_to|knows)\s+", "", value)
    tokens = _evidence_tokens(value)
    # Canonicalize misspellings/synonyms and remove repeated canonical tokens.
    # Example: "زكاء اصتناعي" should collapse to one canonical AI token.
    tokens = list(dict.fromkeys(tokens))
    return " ".join(tokens) if tokens else value

def _same_evidence(left, right):
    a, b = _evidence_identity(left), _evidence_identity(right)
    if not a or not b:
        return False
    if a == b:
        return True
    ta, tb = set(a.split()), set(b.split())
    if not ta or not tb:
        return False
    # Conservative near-duplicate merge; avoid merging merely related facts.
    overlap = len(ta & tb) / max(1, len(ta | tb))
    shorter_coverage = len(ta & tb) / max(1, min(len(ta), len(tb)))
    return overlap >= 0.72 or (shorter_coverage == 1.0 and abs(len(ta)-len(tb)) <= 2)

def local_evidence_search(query, limit=5):
    """Search local memory/graph, canonicalize common Arabic-English terms, merge duplicate evidence."""
    query_tokens = set(_evidence_tokens(query))
    if not query_tokens:
        return []

    candidates = []
    categories = globals().get("CATEGORIES", [])
    for category in categories:
        if category == "profile":
            name = get_name()
            if name:
                candidates.append({"text": f"الاسم: {name}", "source": "memory.profile.name", "category": "profile"})
            continue
        values = MEMORY.get(category, [])
        if not isinstance(values, list):
            continue
        for item in values:
            if isinstance(item, str):
                text, source, created_at = item, "memory." + category, ""
            elif isinstance(item, dict):
                text = str(item.get("text", "")).strip()
                source = str(item.get("source", "memory." + category))
                created_at = str(item.get("created_at", ""))
            else:
                continue
            if text:
                candidates.append({"text": text, "source": source, "category": category, "created_at": created_at})

    for node in KNOWLEDGE.get("nodes", []):
        if isinstance(node, dict) and node.get("name"):
            candidates.append({"text": str(node["name"]), "source": "knowledge_graph.node", "category": str(node.get("type", "concept"))})
    for edge in KNOWLEDGE.get("edges", []):
        if isinstance(edge, dict):
            text = " ".join(str(edge.get(k, "")) for k in ("source", "relation", "target")).strip()
            if text:
                candidates.append({"text": text, "source": "knowledge_graph.relation", "category": "relation"})

    merged = []
    for item in candidates:
        tokens = set(_evidence_tokens(item["text"]))
        overlap = query_tokens.intersection(tokens)
        if not overlap:
            continue
        score = len(overlap) / max(1, len(query_tokens))
        match = next((entry for entry in merged if _same_evidence(entry["text"], item["text"])), None)
        if match is not None:
            if item["source"] not in match["sources"]:
                match["sources"].append(item["source"])
            match["match_score"] = max(match["match_score"], round(score, 2))
            if len(item["text"]) < len(match["text"]) and item.get("category") != "relation":
                match["text"] = item["text"]
                match["category"] = item.get("category", match["category"])
            if item.get("created_at") and not match.get("created_at"):
                match["created_at"] = item["created_at"]
        else:
            merged.append({**item, "sources": [item["source"]], "match_score": round(score, 2)})
    merged.sort(key=lambda item: (item["match_score"], len(item["text"])), reverse=True)
    return merged[:max(1, int(limit))]

def evidence_command(text):
    original = str(text).strip()
    clean = normalize_text(original)
    prefixes = [
        "استرجع ", "ابحث في الذاكره عن ", "مصادر الاجابه عن ", "ما الذي تعرفه عن ",
        "ماذا تعرف عن ", "local search ", "retrieve ", "search local memory for "
    ]
    query = None
    for prefix in prefixes:
        normalized_prefix = normalize_text(prefix)
        if clean.startswith(normalized_prefix):
            # Remove the command from the original text without relying on character length,
            # because Arabic normalization can change character count.
            original_words = original.split()
            prefix_words = prefix.split()
            query = " ".join(original_words[len(prefix_words):]).strip()
            break
    if query is None:
        return None
    if not query:
        return "اكتب موضوع البحث بعد الأمر، مثال: استرجع التكنولوجيا"
    results = local_evidence_search(query)
    if not results:
        return "لم أجد دليلًا مطابقًا في الذاكرة المحلية أو الجراف. ده لا يثبت إن المعلومة غير موجودة خارج VERA؛ البحث هنا محلي فقط."
    lines = ["VERA Local Evidence Search", "مصادر محلية محفوظة فقط — درجات المطابقة ليست احتمالات للصحة."]
    for index, item in enumerate(results, 1):
        sources = "، ".join(item.get("sources", [item.get("source", "unknown")]))
        line = f"{index}. {item['text']}\n   المصادر: {sources} | النوع: {item.get('category', 'unknown')} | تطابق الكلمات: {item['match_score']:.0%}"
        if item.get("created_at"):
            line += f" | التاريخ: {item['created_at']}"
        lines.append(line)
    lines.append("ملاحظة: وجود المعلومة في الذاكرة لا يضمن صحتها؛ تحقق من المصدر الأصلي عند الحاجة.")
    return "\n".join(lines)

def local_core_status():
    return (
        f"VERA Local Core — {VERSION}\n"
        f"- Local evidence retrieval: ACTIVE\n"
        f"- Memory items loaded: {sum(len(MEMORY.get(c, [])) for c in CATEGORIES if c != 'profile' and isinstance(MEMORY.get(c, []), list))}\n"
        f"- Graph nodes/relations: {len(KNOWLEDGE.get('nodes', []))}/{len(KNOWLEDGE.get('edges', []))}\n"
        f"- External AI: {'configured' if os.environ.get('OPENROUTER_API_KEY') else 'not connected'}\n"
        "- Evidence search is local retrieval, not autonomous learning or proof of truth."
    )



# =========================================================
# VERA 3.5.0 — SAFE PROJECT AGENT / MODULAR UPGRADE CORE
# Offline-first prototype: inspect, plan, critique, snapshot, and validate.
# It does not run arbitrary shell commands or silently overwrite project files.
# =========================================================

AGENT_DIR = BASE_DIR / "agent_workspace"
AGENT_LOG = BASE_DIR / "agent_history.json"
AGENT_EXCLUDED_DIRS = {".git", "__pycache__", "backups", "agent_workspace", ".venv", "venv"}
AGENT_EXCLUDED_NAMES = {"memory.txt", "memory_v2.json", "plans.txt", "identity.json", "conversation.txt", "knowledge_graph.json", "self_evaluation.json", "learning_cases.json"}


def _agent_project_files():
    files = []
    try:
        for path in BASE_DIR.rglob("*"):
            if not path.is_file():
                continue
            rel = path.relative_to(BASE_DIR)
            if any(part in AGENT_EXCLUDED_DIRS for part in rel.parts):
                continue
            if path.name in AGENT_EXCLUDED_NAMES or path.suffix.lower() in {".pyc", ".sqlite", ".db"}:
                continue
            if len(rel.parts) > 3:
                continue
            files.append((rel, path))
    except OSError:
        pass
    return sorted(files, key=lambda item: str(item[0]).lower())


def agent_inspect_project():
    files = _agent_project_files()
    lines = [f"VERA Safe Project Agent — {VERSION}", f"مسار المشروع الحالي: {BASE_DIR}", f"عدد الملفات القابلة للفحص: {len(files)}", ""]
    for rel, path in files[:80]:
        try:
            size = path.stat().st_size
            detail = ""
            if path.suffix == ".py":
                source = path.read_text(encoding="utf-8", errors="replace")
                detail = f" | أسطر تقريبية: {source.count(chr(10)) + 1}"
            lines.append(f"- {rel} ({size} bytes){detail}")
        except OSError:
            lines.append(f"- {rel} (تعذر القراءة)")
    if len(files) > 80:
        lines.append(f"... تم إخفاء {len(files)-80} ملفًا إضافيًا للاختصار.")
    lines += ["", "حدود الأمان: الفحص للقراءة فقط؛ لا يرفع الملفات للإنترنت ولا يشغّل أوامر عشوائية."]
    return "\n".join(lines)


def agent_critique(text):
    """Rule-based adversarial review; not a substitute for expert review or an LLM."""
    goal = text.split(":", 1)[1].strip() if ":" in text else text.strip()
    if not goal:
        return "اكتب الفكرة بعد الأمر، مثال: راجع نقديًا: أخلي فيرا تعدل الكود تلقائيًا."
    risks = []
    low = normalize_text(goal)
    if any(x in low for x in ["تلقائي", "autonomous", "auto edit", "تعدل الكود"]):
        risks.append("التعديل التلقائي قد يكسر ملفات شغالة؛ استخدم نسخة معزولة وموافقة قبل الدمج.")
    if any(x in low for x in ["api", "مفتاح", "key", "فلوس", "تكلفه", "تكلفة"]):
        risks.append("احسب التكلفة وحدود الاستخدام، ولا تضع مفاتيح API داخل الكود أو السجلات.")
    if any(x in low for x in ["ذاكره", "memory", "يتعلم", "learn"]):
        risks.append("حدد ما الذي يُحفظ، ومدة الاحتفاظ، وطريقة التصحيح والحذف، واختبر الاسترجاع لا مجرد الحفظ.")
    if any(x in low for x in ["مستخدمين", "عملاء", "users", "customers"]):
        risks.append("اختبر الخصوصية والعزل بين المستخدمين؛ لا تسمح بوصول ذاكرة مستخدم لآخر.")
    if not risks:
        risks.append("حدد معيار نجاح قابل للقياس، وحالة فشل، واختبارًا قبل التنفيذ.")
    return "مراجعة نقدية للفكرة:\n" + goal + "\n\nالمخاطر/الأسئلة:\n" + "\n".join(f"{i}. {r}" for i, r in enumerate(risks, 1)) + "\n\nدي مراجعة محلية مبنية على قواعد، وليست حكمًا شاملًا على الفكرة."


def agent_make_plan(text):
    goal = text.split(":", 1)[1].strip() if ":" in text else ""
    if not goal:
        return "اكتب الهدف بعد الأمر. مثال: خطط تنفيذ: إضافة نظام مراجعة الكود."
    steps = [
        "فحص الملفات الحالية وتحديد مكان التغيير.",
        "كتابة مواصفات قصيرة ومعايير نجاح واضحة.",
        "إنشاء نسخة عمل معزولة وعدم لمس النسخة الأصلية.",
        "تنفيذ أصغر تغيير يحقق الهدف.",
        "تشغيل فحص الصياغة واختبارات الانحدار المسموح بها.",
        "عرض الفرق والنتائج وطلب موافقة بشرية قبل الدمج."
    ]
    record = {"id": str(uuid.uuid4())[:8], "created_at": timestamp(), "goal": goal, "steps": steps, "status": "PROPOSED"}
    data = safe_json_load(AGENT_LOG, {"version": 1, "plans": []})
    if not isinstance(data, dict): data = {"version": 1, "plans": []}
    data.setdefault("plans", []).append(record)
    if not safe_json_save(AGENT_LOG, data):
        return "تعذر حفظ الخطة؛ لم يتم تعديل ملفات المشروع.\n" + "\n".join(f"{i+1}. {x}" for i, x in enumerate(steps))
    return f"خطة مقترحة محفوظة (ID: {record['id']}) — لم يبدأ التنفيذ.\nالهدف: {goal}\n" + "\n".join(f"{i+1}. {x}" for i, x in enumerate(steps))


def agent_snapshot():
    """Create a separate working snapshot of Python source files, never overwrite originals."""
    import shutil
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    destination = AGENT_DIR / f"snapshot_{stamp}"
    try:
        destination.mkdir(parents=True, exist_ok=False)
        copied = []
        for rel, source in _agent_project_files():
            if source.suffix.lower() != ".py":
                continue
            target = destination / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
            copied.append(str(rel))
        safe_json_save(destination / "snapshot_manifest.json", {"version": VERSION, "created_at": timestamp(), "files": copied, "source": str(BASE_DIR)})
        return f"اتعملت نسخة عمل معزولة: agent_workspace/{destination.name}\nملفات Python المنسوخة: {len(copied)}\nالأصل لم يتغير. النسخة دي لا تنفذ إصلاحات تلقائية لسه."
    except Exception as exc:
        return f"فشل إنشاء نسخة العمل ({type(exc).__name__})؛ ملفات الأصل لم تتغير."


def agent_command(text):
    clean = normalize_text(text)
    if clean in {"افحص المشروع", "فحص المشروع", "inspect project", "project inspect"}:
        return agent_inspect_project()
    if clean in {"اعمل نسخة عمل", "نسخة عمل معزولة", "انشئ نسخة عمل", "create work snapshot"}:
        return agent_snapshot()
    if clean.startswith("راجع نقديا ") or clean.startswith("راجع نقديا:") or clean.startswith("red team ") or clean.startswith("red team:"):
        return agent_critique(text)
    if clean.startswith("خطط تنفيذ ") or clean.startswith("خطه تنفيذ ") or clean.startswith("plan implementation "):
        return agent_make_plan(text)
    if clean in {"حاله وكيل التنفيذ", "حاله وكيل المشروع", "project agent status"}:
        plans = safe_json_load(AGENT_LOG, {"plans": []})
        count = len(plans.get("plans", [])) if isinstance(plans, dict) else 0
        snapshots = len(list(AGENT_DIR.glob("snapshot_*"))) if AGENT_DIR.exists() else 0
        return f"Safe Project Agent {VERSION}\nفحص الملفات: متاح\nخطة تنفيذ محفوظة: {count}\nنسخ عمل معزولة: {snapshots}\nتنفيذ أوامر حرة/تعديل الأصل تلقائيًا: معطّل عمدًا."
    return None


# =========================================================
# MAIN ROUTER
# =========================================================

def vera_response(user):

    clean = normalize_text(user)

    result = agent_command(user)
    if result is not None:
        return result, "safe_project_agent"

    if clean in ["حاله المحرك المحلي", "حالة المحرك المحلي", "local core status", "vera 3 status"]:
        return local_core_status(), "local_core_status"

    result = evidence_command(user)
    if result is not None:
        return result, "local_evidence"

    result = context_command(user)

    if result:
        return result, "context"

    if clean in [
        "بصمه فيرا",
        "هوية فيرا",
        "هويه فيرا",
        "vera identity",
        "vera fingerprint"
    ]:

        return (
            identity_command(),
            "identity"
        )

    if clean in [
        "قواعد فيرا",
        "قواعد الصدق",
        "truthfulness",
        "truthfulness rules"
    ]:

        return (
            truthfulness_command(),
            "truthfulness"
        )

    if clean in [
        "حالة التقييم",
        "حاله التقييم",  # normalize_text converts ة to ه
        "التقييم الذاتي",
        "التقييم الذاتى",
        "self evaluation",
        "self status"
    ]:

        return (
            self_status(),
            "self_evaluation"
        )

    result = integrated_command(user)

    if result:
        return result, "system_report"

    result = safety_command(user)

    if result:
        return result, "system_health"

    result = learning_command(user)

    if result:
        return result, "learning"

    result = knowledge_command(user)

    if result:
        return result, "knowledge"

    result = reasoning_command(user)

    if result:
        return result, "reasoning"

    result = memory_command(user)

    if result:

        sync_old_memory()

        return result, "memory"

    result = planning_command(user)

    if result:
        return result, "planning"

    result = calculator(user)

    if result is not None:
        return result, "calculator"

    if clean in [
        "الساعة كام",
        "الساعه كام",
        "الوقت كام",
        "الوقت",
        "time",
        "what time is it"
    ]:

        return (
            time_command(),
            "time"
        )

    if clean in [
        "النهارده كام",
        "النهارده",
        "انهارده كام",
        "انهارده",
        "انهاردة كام",
        "انهاردة",
        "تاريخ النهارده",
        "تاريخ انهارده",
        "تاريخ انهاردة",
        "تاريخ اليوم",
        "date",
        "today",
        "what is today's date"
    ]:

        return (
            date_command(),
            "date"
        )

    if clean in [
        "اعرض الملفات",
        "الملفات",
        "show files",
        "files"
    ]:

        return (
            files_command(),
            "files"
        )

    result = profile_command(user)

    if result:
        return result, "profile"

    result = greeting(user)

    if result:
        return result, "greeting"

    result = about_command(user)

    if result:
        return result, "about"

    result = help_command(user)

    if result:
        return result, "help"

    result = ai_status_command(user)

    if result:
        return result, "ai_status"

    ai_result = openrouter_response(user)

    if ai_result is not None:
        return ai_result, "ai"

    return (
        unknown_response(),
        "unknown"
    )


# =========================================================
# BUILT-IN SELF TESTS
# =========================================================

def run_self_tests():
    """Small offline checks. Run only from an isolated test folder."""
    import copy
    import shutil

    checks = []
    backup_root = BASE_DIR / "backups"
    backup_dirs_before = set(backup_root.iterdir()) if backup_root.exists() else set()
    checks.append(("Arabic normalization", normalize_text("أخضر؟") == normalize_text("اخضر")))

    original_memory = copy.deepcopy(MEMORY)
    original_graph = copy.deepcopy(KNOWLEDGE)
    memory_file_backup = MEMORY_V2_FILE.read_bytes() if MEMORY_V2_FILE.exists() else None
    graph_file_backup = KNOWLEDGE_FILE.read_bytes() if KNOWLEDGE_FILE.exists() else None
    plan_file_backup = PLAN_FILE.read_bytes() if PLAN_FILE.exists() else None
    eval_file_backup = SELF_EVAL_FILE.read_bytes() if SELF_EVAL_FILE.exists() else None
    learning_file_backup = LEARNING_FILE.read_bytes() if LEARNING_FILE.exists() else None

    try:
        MEMORY.clear()
        MEMORY.update(empty_memory())
        KNOWLEDGE.clear()
        KNOWLEDGE.update({"version": 1, "nodes": [], "edges": []})

        add_memory("profile", "test_user", source="self_test")
        first_color = add_memory("facts", "لوني المفضل اخضر", source="self_test")
        duplicate_color = add_memory("facts", "لوني المفضل اخضر", source="self_test")
        checks.append(("Name memory", get_name() == "test_user"))
        checks.append(("Keyed fact saved", first_color and get_keyed_memory("favorite_color") == "لوني المفضل اخضر"))
        checks.append(("Duplicate current fact blocked", not duplicate_color))
        add_memory("facts", "لوني المفضل احمر", source="self_test")
        checks.append(("New current value replaces old", get_keyed_memory("favorite_color") == "لوني المفضل احمر"))
        checks.append(("Old value retained in timeline", any(item.get("key") == "favorite_color" and item.get("text") == "لوني المفضل اخضر" for item in MEMORY.get("events", []))))
        checks.append(("Duplicate relation prevention", add_relation("test_user", "likes", "technology") and not add_relation("test_user", "likes", "technology")))
        sync_memory_to_graph()
        checks.append(("Graph creates nodes", len(KNOWLEDGE.get("nodes", [])) >= 2))
        checks.append(("Graph creates relationships", len(KNOWLEDGE.get("edges", [])) >= 1))

        # Router regression checks for commands that previously failed because
        # normalized Arabic spellings were not included in alias lists.
        write_plan([
            "GOAL: test goal",
            "STATUS: ACTIVE",
            "CURRENT: 1",
            "STEP 1: test step | PENDING"
        ])
        plan_eval_result, plan_eval_category = vera_response("قيم الخطة")
        checks.append(("Plan evaluation command routes", plan_eval_category == "planning" and "VERA Self-Evaluation" in plan_eval_result))
        status_result, status_category = vera_response("حالة التقييم")
        checks.append(("Self-evaluation status command routes", status_category == "self_evaluation" and "Self-Evaluation" in status_result))

        write_plan([
            "GOAL: test task completion",
            "STATUS: ACTIVE",
            "CURRENT: 1",
            "STEP 1: first test step | PENDING",
            "STEP 2: second test step | PENDING"
        ])
        completion_result = planning_command("خلصت المهمة")
        plan_after_completion = get_plan()
        checks.append(("Finish-task Arabic command matches after normalization", completion_result is not None and "خلصنا المهمة 1" in completion_result))
        checks.append(("Finish-task updates status and advances current step", plan_after_completion.get("current") == 2 and plan_after_completion.get("steps", [{}])[0].get("status") == "DONE"))

        LEARNING_FILE.unlink(missing_ok=True)
        learn_result = record_learning_case("Arabic command fails", "Check normalized command aliases")
        duplicate_result = record_learning_case("Arabic command fails", "Check normalized command aliases")
        saved_cases = load_learning_cases().get("cases", [])
        search_result = learning_command("ابحث في التجارب command")
        checks.append(("Learning case is saved locally", "حفظت التجربة بنجاح" in learn_result and len(saved_cases) == 1))
        checks.append(("Duplicate learning case is blocked", "محفوظة بالفعل" in duplicate_result and len(load_learning_cases().get("cases", [])) == 1))
        checks.append(("Learning case search works", search_result is not None and "Check normalized command aliases" in search_result))

        graph_before_audit = copy.deepcopy(KNOWLEDGE)
        KNOWLEDGE.clear()
        KNOWLEDGE.update({"version": 1, "nodes": [
            {"id": "a", "name": "Alice", "type": "person"},
            {"id": "b", "name": "alice", "type": "person"},
            {"id": "c", "name": "Bob", "type": "person"}
        ], "edges": [
            {"source": "Alice", "relation": "likes", "target": "Bob"},
            {"source": "alice", "relation": "LIKES", "target": "bob"},
            {"source": "Bob", "relation": "knows", "target": "Missing"}
        ]})
        audit_text = audit_knowledge_graph(False)
        checks.append(("Graph audit detects structural issues", "عُقد مكررة" in audit_text and "علاقات مكررة" in audit_text))
        repair_text = audit_knowledge_graph(True)
        checks.append(("Graph repair removes duplicates and adds missing nodes", "تم إصلاح الجراف" in repair_text and len(KNOWLEDGE["nodes"]) == 3 and len(KNOWLEDGE["edges"]) == 2))
        health_text = system_health_report()
        checks.append(("System health command reports status", "VERA System Health" in health_text and "التحذيرات" in health_text))
        backup_text = create_local_backup()
        created_backup_dirs = (set(backup_root.iterdir()) - backup_dirs_before) if backup_root.exists() else set()
        backup_has_manifest = any((d / "backup_manifest.json").exists() for d in created_backup_dirs)
        checks.append(("Local backup creates manifest", "تم إنشاء نسخة احتياطية" in backup_text and backup_has_manifest))

        memory_before_audit = copy.deepcopy(MEMORY)
        MEMORY.clear()
        MEMORY.update({"version": 3, "profile": {"name": "test"}, "preferences": [], "likes": [
            {"text": "technology", "source": "test"},
            {"text": "Technology", "source": "test"},
            {"text": "", "source": "test"}
        ], "dislikes": [], "goals": [], "projects": [], "facts": [], "events": [
            {"text": "same event", "source": "test"}, {"text": "same event", "source": "test"}
        ]})
        memory_audit_text = audit_memory(False)
        checks.append(("Memory audit detects duplicates and invalid entries", "مكررة" in memory_audit_text and "غير صالحة" in memory_audit_text))
        memory_repair_text = audit_memory(True)
        checks.append(("Memory repair deduplicates active lists and preserves timeline", "تم إصلاح بنية الذاكرة" in memory_repair_text and len(MEMORY["likes"]) == 1 and len(MEMORY["events"]) == 2))

        write_plan(["GOAL: plan audit test", "STATUS: ACTIVE", "CURRENT: 9", "STEP 1: first | DONE", "STEP 2: second | PENDING"])
        plan_audit_text = audit_plan(False)
        checks.append(("Plan audit detects invalid current step", "رقم المهمة الحالية مش موجود" in plan_audit_text))
        plan_repair_text = audit_plan(True)
        repaired_plan = get_plan()
        checks.append(("Plan repair selects pending step safely", "تم ضبط حالة الخطة" in plan_repair_text and repaired_plan.get("current") == 2 and repaired_plan.get("status") == "ACTIVE"))
        write_plan(["GOAL: completion test", "STATUS: ACTIVE", "CURRENT: 1", "STEP 1: only task | PENDING"])
        complete_result = complete_current_step()
        completed_plan = get_plan()
        checks.append(("Last plan task marks plan completed", "كل مهام الخطة" in complete_result and completed_plan.get("status") == "COMPLETED" and completed_plan.get("steps", [{}])[0].get("status") == "DONE"))
        integrated_text = integrated_status_report()
        checks.append(("Integrated status report summarizes subsystems", "VERA Integrated Status" in integrated_text and "Knowledge Graph" in integrated_text and "AI CONNECTION" in integrated_text))
        report_result, report_category = vera_response("تقرير فيرا")
        checks.append(("Integrated status command routes", report_category == "system_report" and "VERA Integrated Status" in report_result))

        # VERA 3.1 regression checks: Arabic-English synonym matching and source aggregation.
        add_memory("likes", "technology", source="self_test_english_like")
        tech_results = local_evidence_search("التكنولوجيا")
        checks.append(("Arabic technology query matches English technology memory", any("technology" in x["text"].lower() for x in tech_results)))
        add_memory("facts", "هدفي ابني شركة ذكاء اصطناعي", source="self_test_goal_fact")
        KNOWLEDGE.setdefault("nodes", []).append({"name": "هدفي ابني شركة ذكاء اصطناعي", "type": "goal"})
        goal_results = local_evidence_search("استرجع هدفي")
        goal_matches = [x for x in goal_results if "هدفي" in normalize_text(x["text"])]
        checks.append(("Duplicate local evidence is merged with multiple sources", len(goal_matches) <= 1 and (not goal_matches or len(goal_matches[0].get("sources", [])) >= 1)))
        # VERA 3.2 regression: semantically equivalent goal variants from legacy data merge.
        MEMORY.setdefault("facts", []).append({"text": "Goal: ابني شركه ai", "source": "legacy_goal_variant", "created_at": ""})
        KNOWLEDGE.setdefault("nodes", []).append({"name": "هدفي ابني شركه زكاء اصتناعي", "type": "goal"})
        normalized_goal_results = local_evidence_search("استرجع هدفي")
        goal_related = [x for x in normalized_goal_results if "goal" in set(_evidence_tokens(x["text"])) and "build" in set(_evidence_tokens(x["text"]))]
        checks.append(("Equivalent Arabic-English goal variants merge into one result", len(goal_related) == 1 and len(goal_related[0].get("sources", [])) >= 2))

        # VERA 3.0 local evidence retrieval must cite its local source and stay offline.
        add_memory("facts", "بحب التكنولوجيا والذكاء الاصطناعي", source="self_test_saved_fact")
        evidence_result, evidence_category = vera_response("استرجع التكنولوجيا")
        checks.append(("Local evidence search returns saved information", evidence_category == "local_evidence" and "بحب التكنولوجيا" in evidence_result))
        checks.append(("Local evidence search shows provenance and caveat", "المصادر:" in evidence_result and "لا يضمن صحتها" in evidence_result))
        local_status_result, local_status_category = vera_response("حالة المحرك المحلي")
        checks.append(("Local core status routes", local_status_category == "local_core_status" and "Local evidence retrieval: ACTIVE" in local_status_result))
        MEMORY.clear()
        MEMORY.update(memory_before_audit)

        for backup_dir in created_backup_dirs:
            shutil.rmtree(backup_dir, ignore_errors=True)
        if backup_root.exists() and not any(backup_root.iterdir()):
            backup_root.rmdir()
        KNOWLEDGE.clear()
        KNOWLEDGE.update(graph_before_audit)
    except Exception as exc:
        checks.append((f"Self-test exception: {type(exc).__name__}", False))
    finally:
        MEMORY.clear()
        MEMORY.update(original_memory)
        KNOWLEDGE.clear()
        KNOWLEDGE.update(original_graph)
        if memory_file_backup is None:
            MEMORY_V2_FILE.unlink(missing_ok=True)
        else:
            MEMORY_V2_FILE.write_bytes(memory_file_backup)
        if graph_file_backup is None:
            KNOWLEDGE_FILE.unlink(missing_ok=True)
        else:
            KNOWLEDGE_FILE.write_bytes(graph_file_backup)
        if plan_file_backup is None:
            PLAN_FILE.unlink(missing_ok=True)
        else:
            PLAN_FILE.write_bytes(plan_file_backup)
        if eval_file_backup is None:
            SELF_EVAL_FILE.unlink(missing_ok=True)
        else:
            SELF_EVAL_FILE.write_bytes(eval_file_backup)
        if learning_file_backup is None:
            LEARNING_FILE.unlink(missing_ok=True)
        else:
            LEARNING_FILE.write_bytes(learning_file_backup)

    print(f"VERA {VERSION} — Offline Self-Test")
    passed = 0
    for label, ok in checks:
        print(("PASS" if ok else "FAIL") + " | " + label)
        passed += int(bool(ok))
    print(f"Result: {passed}/{len(checks)} checks passed")
    return 0 if passed == len(checks) else 1


# =========================================================
# START
# =========================================================

def main():

    print("====================================")
    print(f"        VERA {VERSION}")
    print("     LOCAL EVIDENCE CORE")
    print("====================================")
    print(f"Version: {VERSION}")
    print("اكتب help للمساعدة.")
    print()

    while True:

        try:

            user = input(
                "You: "
            ).strip()

        except (
            KeyboardInterrupt,
            EOFError
        ):

            print(
                "\nVERA: إلى اللقاء."
            )

            break

        if not user:
            continue

        clean = normalize_text(user)

        if clean in [
            "exit",
            "quit",
            "خروج",
            "اخرج"
        ]:

            print(
                "VERA: إلى اللقاء."
            )

            break

        response, category = vera_response(
            user
        )

        confidence = confidence_for_response(
            response,
            category
        )

        save_self_evaluation(
            user,
            response,
            confidence,
            category
        )

        print(
            "VERA:",
            response
        )

        save_conversation(
            user,
            response
        )


if __name__ == "__main__":
    import sys
    if "--self-test" in sys.argv:
        raise SystemExit(run_self_tests())
    main()
