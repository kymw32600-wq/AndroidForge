package com.vera.chat

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.JavascriptInterface
import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread
import android.view.WindowManager

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null
    private val fileChooserRequestCode = 4104
    private val audioPermissionRequestCode = 4105
    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var pendingLanguage = "ar-EG"
    private var ttsReady = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(6, 11, 9)
        window.navigationBarColor = android.graphics.Color.rgb(6, 11, 9)
        window.decorView.systemUiVisibility = 0
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        textToSpeech = TextToSpeech(this) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) {
                textToSpeech?.language = Locale("ar", "EG")
                textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) { runOnUiThread { web.evaluateJavascript("window.onVeraSpeechDone && window.onVeraSpeechDone()", null) } }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { runOnUiThread { web.evaluateJavascript("window.onVeraSpeechDone && window.onVeraSpeechDone()", null) } }
                })
            }
        }
        web = WebView(this)
        web.setBackgroundColor(android.graphics.Color.rgb(6, 11, 9))
        val s: WebSettings = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.allowFileAccess = false
        s.allowContentAccess = true
        s.loadsImagesAutomatically = true
        s.cacheMode = WebSettings.LOAD_DEFAULT
        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: WebChromeClient.FileChooserParams?
            ): Boolean {
                fileChooserCallback?.onReceiveValue(null)
                fileChooserCallback = filePathCallback
                return try {
                    val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                    }
                    startActivityForResult(intent, fileChooserRequestCode)
                    true
                } catch (_: Exception) {
                    fileChooserCallback?.onReceiveValue(null)
                    fileChooserCallback = null
                    false
                }
            }
        }
        web.addJavascriptInterface(NativeApi(), "VeraNative")
        setContentView(web)
        if (savedInstanceState == null) web.loadUrl("file:///android_asset/index.html") else web.restoreState(savedInstanceState)
    }
    inner class NativeApi {
        @JavascriptInterface fun startListening(language: String) {
            runOnUiThread {
                pendingLanguage = if (language.startsWith("en", true)) "en-US" else "ar-EG"
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startNativeListening()
                else requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), audioPermissionRequestCode)
            }
        }
        @JavascriptInterface fun stopListening() { runOnUiThread { try { speechRecognizer?.cancel() } catch (_: Exception) {} } }
        @JavascriptInterface fun speak(text: String, language: String) {
            runOnUiThread {
                if (!ttsReady || textToSpeech == null) { web.evaluateJavascript("window.onVeraSpeechError && window.onVeraSpeechError('محرك النطق مش جاهز. فعّل خدمة تحويل النص إلى كلام من إعدادات الجهاز.')", null); return@runOnUiThread }
                val locale = if (language.startsWith("en", true)) Locale.US else Locale("ar", "EG")
                val tts = textToSpeech ?: return@runOnUiThread
                val result = tts.setLanguage(locale)
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts.language = Locale("ar")
                }
                // Prefer an Arabic voice whose installed name suggests a male voice; otherwise use the best installed Arabic voice.
                val voices = tts.voices?.filter { it.locale.language == locale.language }.orEmpty()
                val male = voices.firstOrNull { !it.name.contains("female", true) && (it.name.contains("male", true) || it.name.contains("man", true) || it.name.contains("masculine", true)) }
                if (male != null) tts.voice = male
                tts.speak(text.take(4500), TextToSpeech.QUEUE_FLUSH, null, "vera-${System.currentTimeMillis()}")
            }
        }
        @JavascriptInterface fun stopSpeaking() { runOnUiThread { textToSpeech?.stop() } }
        @JavascriptInterface fun openUrl(url: String) {
            runOnUiThread {
                try {
                    val uri = Uri.parse(url)
                    if (uri.scheme == "https" || uri.scheme == "http") {
                        startActivity(Intent(Intent.ACTION_VIEW, uri))
                    }
                } catch (_: Exception) { }
            }
        }
        @JavascriptInterface fun request(id: String, url: String, headersJson: String, body: String) {
            thread {
                var status = 0
                var response = "{}"
                try {
                    val conn = (URL(url).openConnection() as HttpURLConnection)
                    conn.requestMethod = "POST"
                    conn.connectTimeout = 25000
                    conn.readTimeout = 60000
                    conn.doOutput = true
                    val headers = JSONObject(headersJson)
                    val keys = headers.keys()
                    while (keys.hasNext()) { val k = keys.next(); conn.setRequestProperty(k, headers.getString(k)) }
                    conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                    status = conn.responseCode
                    val stream = if (status in 200..299) conn.inputStream else conn.errorStream
                    response = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: "{}"
                    conn.disconnect()
                } catch (e: Exception) {
                    response = JSONObject().put("error", JSONObject().put("message", e.message ?: "Network error")).toString()
                }
                val safe = JSONObject.quote(response)
                runOnUiThread { web.evaluateJavascript("window.onVeraNativeResult && window.onVeraNativeResult(${JSONObject.quote(id)}, $status, $safe)", null) }
            }
        }
    }
    private fun startNativeListening() {
        try {
            speechRecognizer?.destroy()
            if (!SpeechRecognizer.isRecognitionAvailable(this)) {
                web.evaluateJavascript("window.onVeraSpeechError && window.onVeraSpeechError('التعرف على الكلام مش متاح على الجهاز. جرّب تفعيل خدمة Google Voice Typing.')", null)
                return
            }
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).also { recognizer ->
                recognizer.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) { web.evaluateJavascript("window.onVeraListeningState && window.onVeraListeningState(true)", null) }
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() { web.evaluateJavascript("window.onVeraListeningState && window.onVeraListeningState(false)", null) }
                    override fun onError(error: Int) {
                        web.evaluateJavascript("window.onVeraListeningState && window.onVeraListeningState(false)", null)
                        web.evaluateJavascript("window.onVeraSpeechError && window.onVeraSpeechError('ما سمعتش كلام واضح. اضغط الميكروفون وجرّب تاني.')", null)
                    }
                    override fun onResults(results: Bundle?) {
                        val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                        web.evaluateJavascript("window.onVeraListeningState && window.onVeraListeningState(false)", null)
                        web.evaluateJavascript("window.onVeraSpeechResult && window.onVeraSpeechResult(${JSONObject.quote(spoken)})", null)
                    }
                    override fun onPartialResults(partialResults: Bundle?) {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, pendingLanguage)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, pendingLanguage)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                }
                recognizer.startListening(intent)
            }
        } catch (_: Exception) {
            web.evaluateJavascript("window.onVeraSpeechError && window.onVeraSpeechError('تعذر تشغيل الميكروفون. راجع إذن الميكروفون وخدمة الصوت.')", null)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == audioPermissionRequestCode) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startNativeListening()
            else web.evaluateJavascript("window.onVeraSpeechError && window.onVeraSpeechError('لازم تسمح لفيرا باستخدام الميكروفون عشان تتكلم معاها.')", null)
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == fileChooserRequestCode) {
            val callback = fileChooserCallback ?: return
            val results = if (resultCode == RESULT_OK) WebChromeClient.FileChooserParams.parseResult(resultCode, data) else null
            callback.onReceiveValue(results)
            fileChooserCallback = null
        }
    }

    override fun onSaveInstanceState(outState: Bundle) { web.saveState(outState); super.onSaveInstanceState(outState) }
    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        // evaluateJavascript is asynchronous and returns Unit; inspect its callback result instead.
        web.evaluateJavascript("document.body.classList.contains('panel-open')") { result ->
            if (result == "true") {
                web.evaluateJavascript("closeOverlays()", null)
            } else if (web.canGoBack()) {
                web.goBack()
            } else {
                web.evaluateJavascript("closeOverlays()", null)
            }
        }
    }
    override fun onDestroy() { fileChooserCallback?.onReceiveValue(null); fileChooserCallback = null; speechRecognizer?.destroy(); speechRecognizer = null; textToSpeech?.stop(); textToSpeech?.shutdown(); textToSpeech = null; web.destroy(); super.onDestroy() }
}
