#!/usr/bin/env node
const base = process.env.VERA_API || 'http://127.0.0.1:3000';
const r = await fetch(`${base}/health`);
if (!r.ok) throw new Error(`Health check failed: ${r.status}`);
const j = await r.json();
if (!j.ok || j.name !== 'VERA Network API') throw new Error('Unexpected health response');
console.log('VERA API health check: PASS');
