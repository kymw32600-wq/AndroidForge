import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import multer from 'multer';
import fs from 'node:fs';
import path from 'node:path';
import { z } from 'zod';
import { db } from './db.js';
import { auth } from './middleware.js';

if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) {
  console.error('JWT_SECRET must be set to at least 32 characters. Copy .env.example to .env and set a secure secret.');
  process.exit(1);
}
const app = express();
const mediaDir = process.env.MEDIA_DIR || './media';
fs.mkdirSync(mediaDir, { recursive: true });
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.use(cors({ origin: process.env.CORS_ORIGIN?.split(',') || false }));
app.use(express.json({ limit: '1mb' }));
app.use('/media', express.static(mediaDir, { fallthrough: false, maxAge: '7d' }));
app.use(rateLimit({ windowMs: 60_000, limit: 120, standardHeaders: 'draft-7', legacyHeaders: false }));
const upload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, mediaDir),
    filename: (_req, file, cb) => cb(null, `${Date.now()}-${Math.random().toString(36).slice(2)}${path.extname(file.originalname).slice(0, 8)}`)
  }),
  limits: { fileSize: Number(process.env.MAX_UPLOAD_MB || 100) * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const ok = /^(image\/(jpeg|png|webp|gif)|video\/(mp4|webm|quicktime))$/.test(file.mimetype);
    cb(ok ? null : new Error('Unsupported media type'), ok);
  }
});
const now = () => new Date().toISOString();
const tokenFor = user => jwt.sign({ id: user.id, username: user.username }, process.env.JWT_SECRET, { expiresIn: '30d' });
const userView = u => ({ id: u.id, username: u.username, bio: u.bio, createdAt: u.created_at });
const registerSchema = z.object({
  username: z.string().min(3).max(24).regex(/^[a-zA-Z0-9_]+$/),
  email: z.string().email().max(254),
  password: z.string().min(10).max(72)
});

app.get('/health', (_req, res) => res.json({ ok: true, name: 'VERA Network API', version: '1.1.0' }));

app.post('/api/auth/register', async (req, res) => {
  const parsed = registerSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Invalid registration data', details: parsed.error.flatten() });
  const { username, email, password } = parsed.data;
  try {
    const hash = await bcrypt.hash(password, 12);
    const result = db.prepare('INSERT INTO users(username,email,password_hash,created_at) VALUES(?,?,?,?)').run(username, email.toLowerCase(), hash, now());
    const user = db.prepare('SELECT * FROM users WHERE id=?').get(result.lastInsertRowid);
    res.status(201).json({ token: tokenFor(user), user: userView(user) });
  } catch (e) {
    if (String(e).includes('UNIQUE')) return res.status(409).json({ error: 'Username or email already exists' });
    res.status(500).json({ error: 'Could not create account' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  const schema = z.object({ login: z.string().min(1), password: z.string().min(1) });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Login and password are required' });
  const u = db.prepare('SELECT * FROM users WHERE username=? OR email=?').get(parsed.data.login, parsed.data.login.toLowerCase());
  if (!u || !(await bcrypt.compare(parsed.data.password, u.password_hash))) return res.status(401).json({ error: 'Incorrect login details' });
  res.json({ token: tokenFor(u), user: userView(u) });
});

app.get('/api/me', auth, (req, res) => {
  const u = db.prepare('SELECT * FROM users WHERE id=?').get(req.user.id);
  res.json({ user: userView(u) });
});

app.patch('/api/me', auth, (req, res) => {
  const schema = z.object({ bio: z.string().max(300) });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Bio must be 300 characters or less' });
  db.prepare('UPDATE users SET bio=? WHERE id=?').run(parsed.data.bio, req.user.id);
  res.json({ ok: true });
});

app.get('/api/users/:username', auth, (req, res) => {
  const u = db.prepare('SELECT id,username,bio,created_at FROM users WHERE username=?').get(req.params.username);
  if (!u) return res.status(404).json({ error: 'User not found' });
  const counts = {
    followers: db.prepare('SELECT count(*) n FROM follows WHERE followed_id=?').get(u.id).n,
    following: db.prepare('SELECT count(*) n FROM follows WHERE follower_id=?').get(u.id).n
  };
  res.json({ user: userView(u), ...counts });
});

app.post('/api/users/:id/follow', auth, (req, res) => {
  const target = Number(req.params.id);
  if (!Number.isInteger(target) || target === req.user.id) return res.status(400).json({ error: 'Invalid user' });
  try {
    db.prepare('INSERT INTO follows(follower_id,followed_id,created_at) VALUES(?,?,?)').run(req.user.id, target, now());
    res.json({ following: true });
  } catch { res.status(409).json({ error: 'Already following or user unavailable' }); }
});

app.get('/api/feed', auth, (req, res) => {
  const limit = Math.min(Math.max(Number(req.query.limit) || 30, 1), 50);
  const rows = db.prepare(`
    SELECT p.id,p.body,p.media_path,p.media_type,p.created_at,u.id user_id,u.username,
    (SELECT count(*) FROM likes l WHERE l.post_id=p.id) likes,
    EXISTS(SELECT 1 FROM likes l WHERE l.post_id=p.id AND l.user_id=?) liked
    FROM posts p JOIN users u ON u.id=p.user_id ORDER BY p.id DESC LIMIT ?
  `).all(req.user.id, limit);
  res.json({ posts: rows });
});

app.post('/api/posts', auth, upload.single('media'), (req, res) => {
  const body = String(req.body.body || '').slice(0, 5000);
  if (!body.trim() && !req.file) return res.status(400).json({ error: 'Post text or media is required' });
  const result = db.prepare('INSERT INTO posts(user_id,body,media_path,media_type,created_at) VALUES(?,?,?,?,?)')
    .run(req.user.id, body, req.file ? `/media/${req.file.filename}` : null, req.file?.mimetype || null, now());
  res.status(201).json({ id: result.lastInsertRowid, body, media: req.file ? `/media/${req.file.filename}` : null });
});

app.post('/api/posts/:id/like', auth, (req, res) => {
  const id = Number(req.params.id);
  const existing = db.prepare('SELECT 1 FROM likes WHERE user_id=? AND post_id=?').get(req.user.id, id);
  if (existing) {
    db.prepare('DELETE FROM likes WHERE user_id=? AND post_id=?').run(req.user.id, id);
    return res.json({ liked: false });
  }
  try { db.prepare('INSERT INTO likes(user_id,post_id,created_at) VALUES(?,?,?)').run(req.user.id, id, now()); }
  catch { return res.status(404).json({ error: 'Post not found' }); }
  res.json({ liked: true });
});

app.get('/api/posts/:id/comments', auth, (req, res) => {
  const rows = db.prepare('SELECT c.id,c.body,c.created_at,u.username FROM comments c JOIN users u ON u.id=c.user_id WHERE c.post_id=? ORDER BY c.id ASC').all(Number(req.params.id));
  res.json({ comments: rows });
});
app.post('/api/posts/:id/comments', auth, (req, res) => {
  const schema = z.object({ body: z.string().trim().min(1).max(1000) });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Comment must be 1–1000 characters' });
  const result = db.prepare('INSERT INTO comments(user_id,post_id,body,created_at) VALUES(?,?,?,?)').run(req.user.id, Number(req.params.id), parsed.data.body, now());
  res.status(201).json({ id: result.lastInsertRowid });
});

app.get('/api/messages/:userId', auth, (req, res) => {
  const other = Number(req.params.userId);
  const rows = db.prepare(`SELECT id,sender_id,receiver_id,body,created_at,delivered_at FROM messages
    WHERE (sender_id=? AND receiver_id=?) OR (sender_id=? AND receiver_id=?) ORDER BY id DESC LIMIT 100`)
    .all(req.user.id, other, other, req.user.id);
  res.json({ messages: rows.reverse() });
});
app.post('/api/messages/:userId', auth, (req, res) => {
  const schema = z.object({ body: z.string().trim().min(1).max(5000) });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Message must be 1–5000 characters' });
  const result = db.prepare('INSERT INTO messages(sender_id,receiver_id,body,created_at) VALUES(?,?,?,?)')
    .run(req.user.id, Number(req.params.userId), parsed.data.body, now());
  res.status(201).json({ id: result.lastInsertRowid, queued: false });
});

app.get('/api/search', auth, (req, res) => {
  const q = String(req.query.q || '').trim().slice(0, 40);
  if (!q) return res.json({ users: [] });
  const users = db.prepare('SELECT id,username,bio FROM users WHERE username LIKE ? LIMIT 20').all(`%${q}%`);
  res.json({ users });
});

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(err.code === 'LIMIT_FILE_SIZE' ? 413 : 400).json({ error: err.message || 'Request failed' });
});
const port = Number(process.env.PORT || 3000);
app.listen(port, '0.0.0.0', () => console.log(`VERA API listening on :${port}`));
