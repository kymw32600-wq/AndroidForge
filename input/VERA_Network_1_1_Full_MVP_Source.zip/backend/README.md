# VERA Network API

## Local setup
1. Install Node.js 22.
2. Copy `.env.example` to `.env`.
3. Set `JWT_SECRET` to a random secret of at least 32 characters.
4. Run `npm install` then `npm start`.
5. Check `GET /health`.

## API routes
- `POST /api/auth/register` `{username,email,password}` (password min 10 chars)
- `POST /api/auth/login` `{login,password}`
- `GET /api/me` (Bearer token)
- `PATCH /api/me` `{bio}`
- `GET /api/users/:username`
- `POST /api/users/:id/follow`
- `GET /api/feed`
- `POST /api/posts` multipart: `body` and optional `media`
- `POST /api/posts/:id/like`
- `GET /api/posts/:id/comments`
- `POST /api/posts/:id/comments` `{body}`
- `GET /api/messages/:userId`
- `POST /api/messages/:userId` `{body}`
- `GET /api/search?q=...`

## Before public launch
This API is an MVP backend, not yet a hardened production service. Add email verification, password reset, moderation/report/block tools, private-media authorization, push notifications, end-to-end encryption for private messages, backups/restore drills, object storage/CDN, monitoring, TLS reverse proxy, abuse detection and legal/privacy review. Never expose the development database or media volume publicly.
