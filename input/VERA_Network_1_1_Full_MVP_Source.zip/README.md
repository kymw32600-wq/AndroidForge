# VERA Network 1.1 — Full MVP Source

An offline-first social-network foundation for Android with a separate API backend.

## What is included
### Android
- Premium dark Compose shell and navigation: Home, Explore, Create, Messages, Profile.
- Local-first text-post storage.
- Offline state indication for locally stored posts.
- Server URL setting for future API connection.
- WorkManager dependency and scheduled sync foundation.

### Backend API
- Account registration/login with bcrypt password hashing and JWT sessions.
- User profiles and bio updates.
- User lookup and follow.
- Social feed.
- Text and image/video post upload.
- Likes and comments.
- Direct-message storage and retrieval.
- Search.
- SQLite persistence, input validation, rate limiting, security headers and upload limits.
- Dockerfile and Docker Compose.

## Critical status
This is a substantially expanded **full MVP source foundation**, not a finished production social network. The Android UI is not yet wired to all backend endpoints; its sync worker is intentionally a safe placeholder. Real-time chat, push notifications, video transcoding/streaming, robust offline queue conflict handling, Wi-Fi Direct peer transfer, moderation/admin console, and production deployment still require implementation and device/server testing.

No APK is included because this environment does not have an Android SDK/Gradle build environment available. GitHub Actions is configured to build one after upload.

## Build APK on GitHub
1. Create a repository named `VERA-Network`.
2. Upload the entire ZIP contents, including hidden `.github` directory.
3. Go to **Actions** → **Build VERA Android APK** → **Run workflow**.
4. Open the completed run and download artifact `VERA-Network-debug-apk`.

## Start backend locally
```bash
cd backend
cp .env.example .env
# Set JWT_SECRET to a long random value in .env
npm install
npm start
```
API health endpoint: `http://localhost:3000/health`.

## Do not launch publicly yet
Before public launch, complete the security and production checklist in `backend/README.md`, connect Android API/auth/media flows, and test on real Android devices.
