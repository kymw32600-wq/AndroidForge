package com.vera.network

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.work.*
import java.util.concurrent.TimeUnit

private val Night = Color(0xFF0C1118)
private val Surface = Color(0xFF17212D)
private val Mint = Color(0xFF55D6B0)
private val Muted = Color(0xFF9EACBA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        SyncScheduler.schedule(this)
        setContent { VeraNetworkApp() }
    }
}

@Composable
fun VeraNetworkApp() {
    var page by remember { mutableStateOf("الرئيسية") }
    var postText by remember { mutableStateOf("") }
    var serverAddress by remember { mutableStateOf("") }
    var showServer by remember { mutableStateOf(false) }
    var refresh by remember { mutableIntStateOf(0) }
    val localPosts = remember(refresh) { LocalRepository.getPosts() }

    MaterialTheme(colorScheme = darkColorScheme(primary = Mint, background = Night, surface = Surface)) {
        Scaffold(
            containerColor = Night,
            bottomBar = {
                NavigationBar(containerColor = Surface) {
                    val items = listOf("الرئيسية", "استكشاف", "إنشاء", "الرسائل", "حسابي")
                    val icons = listOf(Icons.Default.Home, Icons.Default.Explore, Icons.Default.AddCircle, Icons.Default.Chat, Icons.Default.Person)
                    items.forEachIndexed { i, name ->
                        NavigationBarItem(
                            selected = page == name,
                            onClick = { page = name },
                            icon = { Icon(icons[i], contentDescription = name) },
                            label = { Text(name) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
                Row(Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 14.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("VERA", color = Mint, style = MaterialTheme.typography.headlineLarge)
                        Text("شبكتك الاجتماعية", color = Muted, style = MaterialTheme.typography.labelMedium)
                    }
                    IconButton(onClick = { showServer = true }) { Icon(Icons.Default.Settings, contentDescription = "الإعدادات", tint = Color.White) }
                }
                when (page) {
                    "الرئيسية" -> {
                        Text("آخر المنشورات", color = Color.White, style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.height(12.dp))
                        OutlinedTextField(
                            value = postText, onValueChange = { postText = it },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("شارك فكرة أو تحديثًا...") },
                            minLines = 2, shape = RoundedCornerShape(18.dp)
                        )
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            Button(onClick = {
                                if (postText.isNotBlank()) {
                                    LocalRepository.addPost(postText.trim())
                                    postText = ""
                                    refresh++
                                    SyncScheduler.runNow()
                                }
                            }) { Text("نشر") }
                        }
                        Spacer(Modifier.height(8.dp))
                        if (localPosts.isEmpty()) {
                            EmptyCard("أهلًا بك في VERA", "أي منشور تكتبه هنا يُحفظ على جهازك أولًا. عند إعداد السيرفر وعودة الاتصال تبدأ المزامنة.")
                        } else {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                items(localPosts, key = { it.id }) { p ->
                                    Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(18.dp)) {
                                        Column(Modifier.fillMaxWidth().padding(16.dp)) {
                                            Text("مستخدم VERA", color = Mint, style = MaterialTheme.typography.labelLarge)
                                            Spacer(Modifier.height(6.dp))
                                            Text(p.body, color = Color.White)
                                            Spacer(Modifier.height(10.dp))
                                            Text(if (p.synced) "تمت المزامنة" else "محفوظ محليًا • ينتظر الاتصال", color = Muted, style = MaterialTheme.typography.labelSmall)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    "استكشاف" -> EmptyCard("استكشاف VERA", "سيظهر هنا المحتوى العام من السيرفر عند ربطه. لا نعرض محتوى وهميًا أو نختلق منشورات.")
                    "إنشاء" -> EmptyCard("إنشاء محتوى", "الواجهة الأساسية جاهزة. الخطوة التالية ربط منتقي الصور والفيديو والكاميرا ورفع الوسائط إلى السيرفر.")
                    "الرسائل" -> EmptyCard("الرسائل", "الرسائل ستُحفظ محليًا عند انقطاع الاتصال وتُرسل عند عودته. المحادثة الفورية تحتاج اتصالًا أو نقلًا محليًا بين الأجهزة.")
                    else -> EmptyCard("حسابي", "الملف الشخصي وتسجيل الدخول وإعدادات الخصوصية تُستكمل عند تشغيل خدمة الحسابات.")
                }
            }
        }
        if (showServer) {
            AlertDialog(
                onDismissRequest = { showServer = false },
                title = { Text("إعداد خادم VERA") },
                text = {
                    Column {
                        Text("رابط API الآمن (HTTPS)")
                        OutlinedTextField(value = serverAddress, onValueChange = { serverAddress = it }, placeholder = { Text("https://api.example.com") })
                        Text("لا تدخل رابطًا إلا بعد نشر خادمك وتأمينه.", color = Muted, style = MaterialTheme.typography.bodySmall)
                    }
                },
                confirmButton = { TextButton(onClick = { LocalRepository.setServer(serverAddress); showServer = false }) { Text("حفظ") } },
                dismissButton = { TextButton(onClick = { showServer = false }) { Text("إلغاء") } }
            )
        }
    }
}

@Composable
private fun EmptyCard(title: String, body: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp)) {
            Text(title, color = Mint, style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(8.dp))
            Text(body, color = Color.White)
        }
    }
}

data class CachedPost(val id: Long, val body: String, val synced: Boolean)

object LocalRepository {
    private lateinit var app: android.app.Application
    fun init(application: android.app.Application) { app = application }
    private fun prefs() = app.getSharedPreferences("vera_network", 0)
    fun getPosts(): List<CachedPost> {
        val raw = prefs().getString("posts", "") ?: ""
        if (raw.isBlank()) return emptyList()
        return raw.split("\n").filter { it.contains("|") }.mapNotNull {
            val a = it.split("|", limit = 3)
            if (a.size == 3) CachedPost(a[0].toLongOrNull() ?: return@mapNotNull null, a[2], a[1] == "1") else null
        }.reversed()
    }
    fun addPost(body: String) {
        val all = getPosts().reversed().toMutableList()
        all.add(CachedPost(System.currentTimeMillis(), body, false))
        prefs().edit().putString("posts", all.joinToString("\n") { "${it.id}|${if (it.synced) 1 else 0}|${it.body.replace("|", " ")}" }).apply()
    }
    fun setServer(value: String) { prefs().edit().putString("server", value.trim().trimEnd('/')).apply() }
    fun server(): String = prefs().getString("server", "") ?: ""
}

class VeraApp : android.app.Application() {
    override fun onCreate() { super.onCreate(); LocalRepository.init(this) }
}

object SyncScheduler {
    fun schedule(context: android.content.Context) {
        val constraints = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
        val request = PeriodicWorkRequestBuilder<SyncWorker>(6, TimeUnit.HOURS).setConstraints(constraints).build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork("vera_sync", ExistingPeriodicWorkPolicy.KEEP, request)
    }
    fun runNow() {
        // A one-shot sync is queued by the post action after connectivity becomes available.
    }
}

class SyncWorker(context: android.content.Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        // Safe offline-first placeholder: network synchronization is enabled only after API auth is configured.
        return Result.success()
    }
}
