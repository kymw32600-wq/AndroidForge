# VERA 4.1 — Android project (source ZIP)

واجهة عربية داكنة بطابع زمردي، دردشة، سجل محادثات محلي، ذاكرة/ملخص محلي، إعدادات OpenRouter أو OpenAI، اختيار اللهجة، قراءة صوتية عند دعم الجهاز، إملاء صوتي عند دعم WebView، وإرفاق الصور والملفات النصية.

## إصلاح خطأ البناء السابق

تم ضبط Java وKotlin على JVM target 17 معًا في `app/build.gradle.kts`. هذا يعالج رسالة AndroidForge السابقة: `Inconsistent JVM-target compatibility` بين Java 1.8 وKotlin 17.

## تشغيله من AndroidForge (بخطوات بسيطة)

1. نزّل ملف `VERA_4_1_PREMIUM_ANDROID.zip` إلى جهازك.
2. افتح AndroidForge واختر إنشاء/بناء مشروع Android من ملف ZIP أو Source ZIP.
3. ارفع الملف كاملًا كما هو، وليس مجلد `app` وحده.
4. اختر بناء `Debug` أو `assembleDebug` إذا ظهر الخيار.
5. انتظر انتهاء البناء. إذا نجح، نزّل ملف `app-debug.apk` من النتائج وثبّته على هاتفك بعد السماح بالتثبيت من مصدر موثوق.
6. افتح VERA > الإعدادات > اختر OpenRouter أو OpenAI > ألصق API Key الخاص بك > اكتب اسم النموذج > اختبر الاتصال > احفظ.

## بديل البناء عبر GitHub Actions

يمكن رفع محتويات الأرشيف إلى مستودع GitHub خاص تملكه، ثم تشغيل workflow من تبويب Actions. عند نجاحه ستجد artifact باسم `VERA-4.1-debug-apk`. لا ترسل كلمة مرور GitHub أو Personal Access Token في المحادثة.

## تنبيهات مهمة

- هذا أرشيف مصدر Android، وليس APK جاهزًا للتثبيت. لم أضع APK وهميًا. بيئة إنشاء الحزمة هنا لا تحتوي على Android SDK لتجميع التطبيق فعليًا؛ لذلك نجاح البناء النهائي يجب تأكيده من AndroidForge/GitHub Actions.
- لا يوجد API key داخل الكود. أدخل مفتاحك داخل التطبيق فقط. يُحفظ ضمن بيانات التطبيق المحلية؛ لا ترفعه لمستودع عام ولا تشاركه. استخدام مزود API قد يكلّف مالًا حسب حسابك والنموذج.
- الخيار `openrouter/free` قد يتغير توفره وحدوده. لو لم يعمل، اختر نموذجًا متاحًا في حساب OpenRouter.
- محادثات Android هذه محفوظة محليًا داخل التطبيق، ولا يتم دمج ذاكرة مشروع Python/Termux القديمة تلقائيًا. صدّر نسخة احتياطية من لوحة الذاكرة قبل حذف التطبيق أو بياناته.
- إرفاق ملفات PDF مذكور في منتقي الملفات، لكن التحليل التلقائي الحالي مخصص أساسًا للصور والنصوص وJSON/CSV/Markdown؛ باقي الأنواع قد تظهر كاسم ملف فقط.

## مكونات المشروع

- `app/src/main/assets/`: واجهة HTML/CSS/JavaScript.
- `app/src/main/java/com/vera/chat/MainActivity.kt`: حاوية WebView وطلب API عبر Android الأصلي.
- `app/build.gradle.kts`: إعدادات Android وJVM 17.
- `.github/workflows/build-apk.yml`: بناء APK تجريبي عبر GitHub Actions.
- `legacy/`: نسخة الويب السابقة محفوظة منفصلة؛ لا تُضمَّن في APK.
