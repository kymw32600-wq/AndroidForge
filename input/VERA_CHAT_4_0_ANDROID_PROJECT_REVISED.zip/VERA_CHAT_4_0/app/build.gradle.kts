plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.vera.chat"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.vera.chat"
        minSdk = 26
        targetSdk = 35
        versionCode = 40
        versionName = "4.0.0"
    }
}
