(() => {
  const $ = id => document.getElementById(id);
  const KEY = 'vera4.settings';
  const CHATS = 'vera4.chats';
  const ACTIVE = 'vera4.active';
  let settings = {provider:'openrouter', apiKey:'', model:'openrouter/free', dialect:'تلقائي', voiceAuto:false, mode:'general'};
  let chats = [];
  let activeId = null;
  let pendingFile = null;
  let busy = false;
  let voiceCallActive = false;
  const nativePending = new Map();
  window.onVeraListeningState=function(active){document.body.classList.toggle('voice-listening',!!active);if(active)updateVoiceHero('listening');};
  window.onVeraNativeResult = (id, status, bodyText) => { const p=nativePending.get(id); if(!p)return; nativePending.delete(id); let data={}; try{data=JSON.parse(bodyText||'{}')}catch{} p.resolve({ok:status>=200&&status<300,status,json:async()=>data}); };
  function apiRequest(url, headers, body){ if(window.VeraNative && window.VeraNative.request){ return new Promise(resolve=>{const id=nowId();nativePending.set(id,{resolve});window.VeraNative.request(id,url,JSON.stringify(headers),JSON.stringify(body));}); } return fetch(url,{method:'POST',headers,body:JSON.stringify(body)}); }
  const nowId = () => `${Date.now()}-${Math.random().toString(36).slice(2,7)}`;
  const time = t => new Date(t).toLocaleTimeString('ar-EG',{hour:'2-digit',minute:'2-digit'});
  function load(){
    try { settings = {...settings,...JSON.parse(localStorage.getItem(KEY)||'{}')}; } catch{}
    try { chats = JSON.parse(localStorage.getItem(CHATS)||'[]'); } catch{chats=[];}
    activeId = localStorage.getItem(ACTIVE);
    if(!Array.isArray(chats)) chats=[];
    if(!chats.length){const c={id:nowId(),title:'محادثة جديدة',messages:[],updated:Date.now()};chats=[c];activeId=c.id;persist();}
    if(!chats.some(c=>c.id===activeId)) activeId=chats[0].id;
    syncSettings(); renderHistory(); renderMessages(); updateStatus();
  }
  const activeChat = () => chats.find(c=>c.id===activeId);
  function persist(){localStorage.setItem(CHATS,JSON.stringify(chats));localStorage.setItem(ACTIVE,activeId||'');}
  function persistSettings(){localStorage.setItem(KEY,JSON.stringify(settings));}
  function syncSettings(){ $('provider').value=settings.provider; $('apiKey').value=settings.apiKey; $('model').value=settings.model; $('dialect').value=settings.dialect; $('voiceAuto').checked=!!settings.voiceAuto; if($('defaultMode'))$('defaultMode').value=settings.mode||'general'; if($('workMode'))$('workMode').value=settings.mode||'general'; updateModeHint(); }
  function updateStatus(ok){ const configured=!!(settings.apiKey&&settings.model);$('statusText').textContent=ok===true?'متصلة':ok===false?'راجع الاتصال':configured?'المفتاح محفوظ':'جاهزة للاتصال';$('statusDot').classList.toggle('ok',ok===true||configured); }
  function toast(s){const el=$('toast');el.textContent=s;el.classList.add('show');setTimeout(()=>el.classList.remove('show'),2500);}
  function escapeText(s){return String(s??'');}
  function renderHistory(){const root=$('history');root.replaceChildren();[...chats].sort((a,b)=>b.updated-a.updated).forEach(c=>{const b=document.createElement('button');b.className='history-item'+(c.id===activeId?' active':'');const icon=document.createElement('span');icon.textContent='▤';const name=document.createElement('span');name.textContent=c.title||'محادثة جديدة';b.append(icon,name);b.onclick=()=>{activeId=c.id;persist();renderHistory();renderMessages();closeSidebar();};root.append(b);});}
  function addMessage(role,text,extra={}){const c=activeChat();if(!c)return;const m={id:nowId(),role,text:String(text??''),time:Date.now(),...extra};c.messages.push(m);c.updated=Date.now();if(role==='user'&&c.messages.filter(x=>x.role==='user').length===1)c.title=String(text||'محادثة جديدة').replace(/\s+/g,' ').slice(0,34)||'محادثة جديدة';persist();return m;}
  function renderMessages(){const root=$('messages');root.replaceChildren();const c=activeChat();const has=!!(c&&c.messages.length);$('welcome').style.display=has?'none':'block';if(!c)return;c.messages.forEach(m=>root.append(makeMessage(m)));root.scrollTop=root.scrollHeight;}
  function escapeHtml(value){return String(value??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/\"/g,'&quot;').replace(/'/g,'&#39;');}
  function renderMarkdown(value){let text=escapeHtml(value);const blocks=[];text=text.replace(/```([\w+-]*)\n?([\s\S]*?)```/g,(_,lang,code)=>{const token='@@VERACODE'+blocks.length+'@@';blocks.push('<pre class=\"code-block\"><code>'+code.replace(/\n$/,'')+'</code><button type=\"button\" class=\"copy-code\" data-code=\"'+encodeURIComponent(code.replace(/\n$/,''))+'\">نسخ الكود</button></pre>');return token;});text=text.replace(/`([^`]+)`/g,'<code class=\"inline-code\">$1</code>').replace(/\*\*(.+?)\*\*/g,'<strong>$1</strong>').replace(/^### (.+)$/gm,'<strong class=\"md-heading\">$1</strong>').replace(/^## (.+)$/gm,'<strong class=\"md-heading\">$1</strong>').replace(/^[-*] (.+)$/gm,'• $1').replace(/(https?:\/\/[^\s<]+[^\s<.,;:!?)\]»])/g,url=>'<a class=\"vera-link\" href=\"'+url+'\" data-external-url=\"'+url+'\">'+url+'</a>').replace(/\n/g,'<br>');blocks.forEach((b,i)=>{text=text.replace('@@VERACODE'+i+'@@',b);});return text;}
  function copyText(text){const value=String(text??'');if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(value).then(()=>toast('اتنسخ النص')).catch(()=>fallbackCopy(value));}else fallbackCopy(value);}
  function fallbackCopy(value){const area=document.createElement('textarea');area.value=value;area.style.position='fixed';area.style.opacity='0';document.body.append(area);area.select();try{document.execCommand('copy');toast('اتنسخ النص');}catch{toast('مش قادر أنسخ النص على الجهاز ده');}area.remove();}
  function makeMessage(m){const row=document.createElement('article');row.className='message '+(m.role==='user'?'user':'assistant');const avatar=document.createElement('div');avatar.className='avatar';avatar.textContent=m.role==='user'?'أنت':'V';const wrap=document.createElement('div');wrap.className='message-wrap';if(m.image){const im=document.createElement('img');im.src=m.image;im.alt='صورة مرفقة';wrap.append(im);}const bubble=document.createElement('div');bubble.className='bubble';bubble.innerHTML=renderMarkdown(m.text||'');wrap.append(bubble);if(m.role==='assistant'&&!m.typing){const actions=document.createElement('div');actions.className='message-actions';const copy=document.createElement('button');copy.type='button';copy.className='message-action';copy.textContent='نسخ الرد';copy.onclick=()=>copyText(m.text||'');actions.append(copy);wrap.append(actions);}bubble.querySelectorAll('.copy-code').forEach(b=>b.addEventListener('click',()=>copyText(decodeURIComponent(b.dataset.code||''))));bubble.querySelectorAll('[data-external-url]').forEach(a=>a.addEventListener('click',e=>{e.preventDefault();const url=a.dataset.externalUrl||'';if(/^https?:\/\//i.test(url)&&window.VeraNative&&window.VeraNative.openUrl)window.VeraNative.openUrl(url);else if(/^https?:\/\//i.test(url))window.open(url,'_blank','noopener');}));const meta=document.createElement('div');meta.className='meta';meta.textContent=(m.role==='user'?'أنت':'VERA')+' · '+time(m.time);wrap.append(meta);row.append(avatar,wrap);return row;}
  function openPanel(id){closeSidebar();document.querySelectorAll('.panel').forEach(p=>p.classList.remove('open'));$(id).classList.add('open');$('overlay').classList.add('show');document.body.classList.add('panel-open');}
  function closeOverlays(){document.querySelectorAll('.panel').forEach(p=>p.classList.remove('open'));$('overlay').classList.remove('show');document.body.classList.remove('panel-open');closeSidebar();}
  window.closeOverlays=closeOverlays;
  function closeSidebar(){$('sidebar').classList.remove('open');}
  function newChat(){const c={id:nowId(),title:'محادثة جديدة',messages:[],updated:Date.now()};chats.unshift(c);activeId=c.id;persist();renderHistory();renderMessages();closeOverlays();$('prompt').focus();}
  function modeInstructions(){switch(settings.mode){case 'student':return 'أنت الآن مدرس خصوصي للثانوية العامة المصرية. اسأل عن المادة والباب إذا لم يتضحا. اشرح بالمصري البسيط خطوة بخطوة، اكتب القانون والوحدات والتعويض والتحقق في المسائل، ولا تخترع معلومة من المنهج. إذا لم تكن متأكدًا من إصدار المنهج فقل ذلك. بعد الشرح اعرض سؤال تدريب واحدًا وانتظر الإجابة عند ملاءمة ذلك.';case 'teacher':return 'أنت مساعد للمدرس. ساعد في إعداد شرح منظم وخطة درس وأهداف تعلم وأسئلة متدرجة ومفتاح إجابة منفصل. عند إرفاق مادة نصية، التزم بها وميّز بوضوح بين ما ورد فيها وما أضفته. لا تدّعِ أنك قرأت ملفات PDF أو صورًا لم تستطع استخراج محتواها.';case 'exam':return 'أنت منشئ امتحانات تعليمية. قبل إنشاء امتحان كامل، استخدم تفاصيل المستخدم عن المادة والباب والصف وعدد الأسئلة ومستوى الصعوبة. نوّع أنواع الأسئلة، ضع نموذج الإجابة في قسم منفصل مع توزيع الدرجات، ووضّح أن الأسئلة مولدة وليست امتحانًا رسميًا.';case 'quiz':return 'أنت مدرب تفاعلي. اسأل سؤالًا واحدًا فقط في كل مرة، وانتظر إجابة المستخدم، ثم قيّمها بلطف واشرح سبب الصحة أو الخطأ وقدّم السؤال التالي. لا تكشف الإجابة قبل محاولة المستخدم إلا إذا طلب ذلك.';default:return 'أنت مساعد عام يساعد في التفكير والتعلم والإنجاز.';}}
  function updateModeHint(){const hints={general:'مساعد ذكي لكل مهامك',student:'شرح خطوة بخطوة للثانوية العامة',teacher:'تحضير الدروس وبنوك الأسئلة',exam:'امتحان مولد وإجابات منفصلة',quiz:'سؤال واحد في كل مرة'};if($('modeHint'))$('modeHint').textContent=hints[$('workMode')?.value||settings.mode]||hints.general;}
  function systemPrompt(){const dialect=(settings.dialect&&settings.dialect!=='تلقائي')?`استخدم اللهجة ${settings.dialect} ما لم يطلب المستخدم غير ذلك.`:'تكيّف تلقائيًا مع لغة المستخدم ولهجته الحالية (مصري أو شامي أو خليجي أو فصحى أو غيرها) من غير ما تفرض لهجة من عندك.';return `أنت VERA، مساعد ذكي صريح ومحترم. ${dialect} ${modeInstructions()} لا تخترع حقائق ولا تدّعِ أنك بحثت على الإنترنت أو فتحت رابطًا أو نفذت شيئًا إن لم يحدث ذلك فعلاً. لو لا تملك تصفحًا مباشرًا أو لم تعرف الإجابة، وضّح ذلك واقترح طريقة تحقق. في الروابط، اكتب الرابط الكامل الواضح عندما يكون متاحًا. اربط المعلومات القديمة بالجديدة بحذر، ولا تعتبر الأسئلة أو الاحتمالات حقائق مؤكدة. اشرح بشكل منظم ومفيد، وراعِ أن المستخدم قد يكون على هاتف. اسمك VERA 4.5.`;}
  function apiUrl(){return settings.provider==='openrouter'?'https://openrouter.ai/api/v1/chat/completions':'https://api.openai.com/v1/chat/completions';}
  function apiHeaders(){const h={'Authorization':'Bearer '+settings.apiKey,'Content-Type':'application/json'};if(settings.provider==='openrouter'){h['HTTP-Referer']='https://vera.local';h['X-Title']='VERA 4.5';}return h;}
  // Local cross-chat context: concise excerpts from other saved conversations, never API keys/settings.
  function memoryContext(){
    const current=activeChat();
    const previous=[...chats].filter(c=>c.id!==current?.id&&Array.isArray(c.messages)&&c.messages.length)
      .sort((a,b)=>(b.updated||0)-(a.updated||0)).slice(0,8);
    const lines=[];
    for(const c of previous){
      const userMessages=c.messages.filter(m=>m.role==='user'&&!m.typing&&m.text).slice(-3);
      if(!userMessages.length)continue;
      const title=String(c.title||'محادثة سابقة').slice(0,60);
      lines.push('محادثة سابقة: '+title+'\n'+userMessages.map(m=>'- المستخدم: '+String(m.text).replace(/\s+/g,' ').slice(0,260)).join('\n'));
    }
    return lines.join('\n\n').slice(0,5200);
  }
  function apiMessages(){const c=activeChat();const out=[{role:'system',content:systemPrompt()}];const memory=memoryContext();if(memory)out.push({role:'system',content:'سياق اختياري من محادثات سابقة محفوظة محليًا على نفس الجهاز. استخدمه فقط لو كان ذا صلة، ولا تعتبره حقيقة مؤكدة إذا كان مجرد سؤال أو احتمال. لا تقل إنك تتذكر معلومة شخصية بشكل مؤكد إلا إذا كان النص يدعم ذلك.\n'+memory});for(const m of (c?.messages||[]).filter(x=>!x.typing).slice(-24)){if(m.role==='assistant')out.push({role:'assistant',content:m.text});else if(m.role==='user'){if(m.image&&m.text){out.push({role:'user',content:[{type:'text',text:m.text||'حلل الصورة المرفقة'},{type:'image_url',image_url:{url:m.image}}]});}else out.push({role:'user',content:m.text});}}return out;}
  async function send(){if(busy)return;const input=$('prompt');let text=input.value.trim();if(!text&&!pendingFile)return;if(!settings.apiKey){if(voiceCallActive)stopVoiceCall();openPanel('settingsPanel');toast('ضيف مفتاح API الأول من الإعدادات');return;}if(!settings.model){toast('اكتب اسم النموذج في الإعدادات');return;}
    let image='';if(pendingFile){if(pendingFile.type.startsWith('image/'))image=await readImageForApi(pendingFile);else if(/text\/|json|csv/.test(pendingFile.type)||/\.(txt|md|csv|json)$/i.test(pendingFile.name)){try{text+=(text?'\n\n':'')+'محتوى الملف '+pendingFile.name+':\n'+(await pendingFile.text()).slice(0,12000);}catch{}}else{text+=(text?'\n':'')+'[ملف مرفق: '+pendingFile.name+' — محتوى النوع ده مش بيتحلل تلقائيًا حاليًا]';}}
    if(!text)text='حلل الصورة المرفقة.';const file=image?pendingFile:null;addMessage('user',text,{image:image||undefined,fileName:file?.name});input.value='';input.style.height='auto';pendingFile=null;$('attachmentPreview').replaceChildren();renderMessages();busy=true;$('sendBtn').disabled=true;const waiting=addMessage('assistant','بفكّر…',{typing:true});renderMessages();
    try{const body={model:settings.model,messages:apiMessages(),temperature:0.6,max_tokens:1800};const res=await apiRequest(apiUrl(),apiHeaders(),body);const data=await res.json();if(!res.ok)throw new Error(data?.error?.message||`خطأ API (${res.status})`);let answer=data?.choices?.[0]?.message?.content;if(Array.isArray(answer))answer=answer.map(x=>typeof x==='string'?x:(x?.text||'')).join('\n');if(typeof answer!=='string'||!answer.trim())throw new Error('النموذج رجّع رد فاضي.');const c=activeChat();const idx=c.messages.findIndex(m=>m.id===waiting.id);if(idx>=0)c.messages.splice(idx,1);addMessage('assistant',answer.trim());if(settings.voiceAuto||voiceCallActive){if(voiceCallActive){$('voiceTranscript').textContent='VERA: '+answer.trim().slice(0,450);updateVoiceHero('speaking');}speak(answer.trim());}updateStatus(true);persist();renderHistory();renderMessages();
    }catch(e){const c=activeChat();const idx=c.messages.findIndex(m=>m.id===waiting.id);if(idx>=0)c.messages.splice(idx,1);addMessage('assistant','مش قادر أوصل للنموذج دلوقتي.\n\n'+friendlyError(e.message));updateStatus(false);persist();renderMessages();if(voiceCallActive){$('voiceTranscript').textContent='تعذر الرد: '+friendlyError(e.message);speak('حصلت مشكلة في الاتصال بالنموذج. '+friendlyError(e.message));}}
    finally{busy=false;$('sendBtn').disabled=false;$('prompt').focus();}
  }
  function friendlyError(msg){if(/401|Incorrect API key|invalid_api_key/i.test(msg))return 'مفتاح API غير صحيح. افتح الإعدادات وراجعه.';if(/quota|billing|insufficient/i.test(msg))return 'حساب الـ API ممكن يكون مفيهوش رصيد أو حد الاستخدام خلص. راجع الفوترة عند مزود الخدمة.';if(/Failed to fetch|NetworkError|Load failed/i.test(msg))return 'في مشكلة اتصال بالإنترنت أو اتصال مزود الخدمة.';return msg||'حصل خطأ غير معروف.';}
  function readImageForApi(file){return new Promise((resolve,reject)=>{const r=new FileReader();r.onerror=reject;r.onload=()=>{const img=new Image();img.onerror=()=>resolve(String(r.result));img.onload=()=>{try{const scale=Math.min(1,1280/Math.max(img.naturalWidth,img.naturalHeight));const c=document.createElement('canvas');c.width=Math.max(1,Math.round(img.naturalWidth*scale));c.height=Math.max(1,Math.round(img.naturalHeight*scale));c.getContext('2d').drawImage(img,0,0,c.width,c.height);resolve(c.toDataURL('image/jpeg',0.82));}catch{resolve(String(r.result));}};img.src=String(r.result);};r.readAsDataURL(file);});}
  function showAttachment(file){pendingFile=file;const p=$('attachmentPreview');p.replaceChildren();const b=document.createElement('button');b.textContent='📎 '+file.name+'  ×';b.onclick=()=>{pendingFile=null;p.replaceChildren();};p.append(b);}
  async function testApi(){const result=$('apiResult');result.textContent='جاري اختبار الاتصال…';const draft={provider:$('provider').value,apiKey:$('apiKey').value.trim(),model:$('model').value.trim()};if(!draft.apiKey||!draft.model){result.textContent='اكتب API Key واسم النموذج الأول.';return;}const url=draft.provider==='openrouter'?'https://openrouter.ai/api/v1/chat/completions':'https://api.openai.com/v1/chat/completions';const headers={'Authorization':'Bearer '+draft.apiKey,'Content-Type':'application/json'};if(draft.provider==='openrouter'){headers['HTTP-Referer']='https://vera.local';headers['X-Title']='VERA 4.5';}try{const r=await apiRequest(url,headers,{model:draft.model,messages:[{role:'user',content:'Reply with OK'}],max_tokens:5});const d=await r.json();if(!r.ok)throw new Error(d?.error?.message||'HTTP '+r.status);result.textContent='✅ الاتصال ناجح والنموذج رد. اضغط حفظ الإعدادات.';}catch(e){result.textContent='❌ '+friendlyError(e.message);}}
  function saveSettings(){const provider=$('provider').value;settings={...settings,provider,apiKey:$('apiKey').value.trim(),model:$('model').value.trim()||(provider==='openrouter'?'openrouter/free':'gpt-4o'),dialect:$('dialect').value,voiceAuto:$('voiceAuto').checked,mode:$('defaultMode')?.value||settings.mode||'general'};persistSettings();updateStatus();closeOverlays();toast('اتحفظت الإعدادات على الجهاز');}
  function memory(){const all=chats.reduce((n,c)=>n+c.messages.length,0);$('memoryText').textContent=`VERA 4.5\nوضع العمل: ${settings.mode||'general'}\nعدد المحادثات: ${chats.length}\nعدد الرسائل: ${all}\nمزود الخدمة: ${settings.provider}\nالنموذج: ${settings.model}\nمفتاح API: ${settings.apiKey?'محفوظ محليًا':'غير مضاف'}\nاللهجة: ${settings.dialect}\n\nالمحادثات محفوظة في مساحة التطبيق على هذا الجهاز. حذف التطبيق أو بياناته قد يحذفها.`;openPanel('memoryPanel');}
  function exportChats(){const blob=new Blob([JSON.stringify({format:'VERA_CHAT_BACKUP_V1',exportedAt:new Date().toISOString(),chats},null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='vera-chat-backup.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
  async function importChats(file){try{const data=JSON.parse(await file.text());if(!Array.isArray(data.chats))throw new Error('الملف مش نسخة احتياطية صحيحة.');const seen=new Set(chats.map(c=>c.id));let added=0;for(const original of data.chats){if(!original||!Array.isArray(original.messages))continue;const c=JSON.parse(JSON.stringify(original));if(!c.id||seen.has(c.id))c.id=nowId();seen.add(c.id);c.title=String(c.title||'محادثة مستوردة');c.updated=Number(c.updated)||Date.now();chats.push(c);added++;}chats.sort((a,b)=>b.updated-a.updated);persist();renderHistory();renderMessages();closeOverlays();toast('تم استيراد '+added+' محادثة');}catch(e){toast(e.message||'فشل استيراد النسخة الاحتياطية');}}
  function speechLanguage(){
    if(settings.dialect==='English')return 'en-US';
    const recent=activeChat()?.messages?.filter(m=>m.role==='user'&&m.text).slice(-1)[0]?.text||'';
    if(settings.dialect==='تلقائي'&&/[A-Za-z]{4,}/.test(recent)&&!/[؀-ۿ]/.test(recent))return 'en-US';
    return 'ar-EG';
  }
  function speak(text){
    document.body.classList.add('voice-speaking');updateVoiceHero('speaking');
    if(window.VeraNative&&window.VeraNative.speak){window.VeraNative.speak(String(text||'').slice(0,4500),speechLanguage());return;}
    if(!('speechSynthesis'in window)){toast('القراءة الصوتية مش متاحة على الجهاز ده');if(voiceCallActive)stopVoiceCall();return;}
    speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(String(text||'').slice(0,4500));u.lang=speechLanguage();const voices=speechSynthesis.getVoices();const v=voices.find(x=>x.lang.toLowerCase().startsWith(u.lang.toLowerCase()))||voices.find(x=>x.lang.toLowerCase().startsWith('ar'));if(v)u.voice=v;u.onend=()=>{if(voiceCallActive)setTimeout(listenForVoiceTurn,350);};speechSynthesis.speak(u);
  }
  function mic(){
    if(window.VeraNative&&window.VeraNative.startListening){window.VeraNative.startListening(speechLanguage());toast('اتكلم دلوقتي؛ الكلام هيتكتب في مربع الرسالة');return;}
    const SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR){toast('الإملاء الصوتي غير متاح هنا؛ جرّب ميكروفون لوحة المفاتيح.');return;}const rec=new SR();rec.lang=speechLanguage();rec.interimResults=false;rec.onresult=e=>{$('prompt').value+=($('prompt').value?' ':'')+e.results[0][0].transcript;$('prompt').focus();};rec.onerror=()=>toast('تعذر تشغيل الميكروفون');rec.start();toast('اتكلم دلوقتي');
  }
  function listenForVoiceTurn(){
    if(!voiceCallActive||busy)return;
    document.body.classList.remove('voice-speaking');document.body.classList.add('voice-listening');updateVoiceHero('listening');
    if(window.VeraNative&&window.VeraNative.startListening){window.VeraNative.startListening(speechLanguage());$('voiceCallBtn').classList.add('active');$('voiceCallBtn').title='المحادثة الصوتية شغالة — اضغط للإيقاف';return;}
    const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
    if(!SR){toast('المحادثة الصوتية غير مدعومة في هذا المتصفح.');stopVoiceCall();return;}
    const rec=new SR();rec.lang=speechLanguage();rec.interimResults=false;rec.maxAlternatives=1;
    rec.onresult=e=>{const text=e.results?.[0]?.[0]?.transcript?.trim();if(text){$('prompt').value=text;send();}};
    rec.onerror=()=>{if(voiceCallActive){toast('تعذر سماعك؛ هنوقف المحادثة الصوتية.');stopVoiceCall();}};
    try{rec.start();}catch{stopVoiceCall();toast('مش قادر أشغل الميكروفون دلوقتي.');}
  }
  function updateVoiceHero(state){const t=$('voiceHeroTitle'),sub=$('voiceHeroSub');if(t&&sub){t.textContent=state==='listening'?'سامعاك… اتكلم':state==='speaking'?'VERA بترد عليك':'اتكلم مع VERA';sub.textContent=state==='listening'?'قول اللي محتاجه، وبعدها اسكت لحظة':state==='speaking'?'اسمع الرد، وهستنى كلامك بعده':'محادثة صوتية · اضغط للبدء أو الإنهاء';} const screen=$('voiceScreen');if(screen){screen.classList.toggle('listening',state==='listening');screen.classList.toggle('speaking',state==='speaking');screen.classList.toggle('thinking',state==='thinking');const st=$('voiceState'),cap=$('voiceCaption');if(st)st.textContent=state==='listening'?'سامعاك… اتكلم':state==='speaking'?'فيرا بتتكلم دلوقتي':state==='thinking'?'بفكر في كلامك…':voiceCallActive?'فيرا جاهزة تسمعك':'محادثة VERA الصوتية';if(cap)cap.textContent=state==='listening'?'اتكلم براحتك، هسمعك وأرد عليك':state==='speaking'?'استمع للرد، وبعده هفتح الميكروفون تاني':'اضغط الزر الأخضر لبدء المحادثة';}document.body.classList.toggle('voice-call-active',voiceCallActive);}
  function startVoiceCall(){
    $('voiceScreen')?.classList.add('open');$('voiceScreen')?.setAttribute('aria-hidden','false');$('voiceMainControl')?.classList.add('active');
    if(!settings.apiKey){openPanel('settingsPanel');toast('ضيف مفتاح API واختبره الأول');return;}
    voiceCallActive=true;$('voiceCallBtn').classList.add('active');$('voiceCallBtn').title='إيقاف المحادثة الصوتية';updateVoiceHero('listening');
    toast('المحادثة الصوتية بدأت. اتكلم بعد سماع نغمة/جاهزية الميكروفون.');
    listenForVoiceTurn();
  }
  function stopVoiceCall(){
    voiceCallActive=false;$('voiceScreen')?.classList.remove('open','listening','speaking','thinking');$('voiceScreen')?.setAttribute('aria-hidden','true');document.body.classList.remove('voice-listening','voice-speaking','voice-call-active');$('voiceCallBtn')?.classList.remove('active');if($('voiceCallBtn'))$('voiceCallBtn').title='بدء محادثة صوتية';updateVoiceHero('ready');
    if(window.VeraNative?.stopListening)window.VeraNative.stopListening();
    if(window.VeraNative?.stopSpeaking)window.VeraNative.stopSpeaking();
    if('speechSynthesis'in window)speechSynthesis.cancel();
    toast('المحادثة الصوتية اتوقفت');
  }
  function toggleVoiceCall(){if(voiceCallActive)stopVoiceCall();else startVoiceCall();}
  $('voiceBack').onclick=stopVoiceCall;$('voiceEnd').onclick=stopVoiceCall;$('voiceMainControl').onclick=()=>{if(voiceCallActive){if(window.VeraNative?.stopListening)window.VeraNative.stopListening();if('speechSynthesis'in window)speechSynthesis.cancel();voiceCallActive=false;stopVoiceCall();}else startVoiceCall();};$('voiceMute').onclick=()=>{if('speechSynthesis'in window)speechSynthesis.cancel();toast('لو عايز توقف المحادثة اضغط ×');};
  window.onVeraSpeechResult=function(text){
    if(!text){if(voiceCallActive)setTimeout(listenForVoiceTurn,350);else toast('ماسمعتش كلام واضح.');return;}
    if(voiceCallActive){$('voiceTranscript').textContent='إنت: '+String(text);updateVoiceHero('thinking');$('prompt').value=String(text);send();}
    else{$('prompt').value+=($('prompt').value?' ':'')+String(text);$('prompt').focus();toast('اتكتب كلامك في مربع الرسالة');}
  };
  window.onVeraSpeechError=function(message){
    if(!voiceCallActive){toast(message||'تعذر تشغيل الصوت');return;}
    if(/ماسمعتش كلام واضح|ماسمعتش كلام|لم يتم العثور|timeout/i.test(message||'')){toast(message||'ماسمعتش كلام واضح؛ اتكلم تاني');setTimeout(listenForVoiceTurn,450);return;}
    toast(message||'حصل خطأ في الصوت');stopVoiceCall();
  };
  window.onVeraSpeechDone=function(){document.body.classList.remove('voice-speaking');if(voiceCallActive)setTimeout(listenForVoiceTurn,350);else updateVoiceHero('ready');};
  window.onVeraSpeechUnavailable=function(){toast('محرك تحويل النص لصوت مش جاهز على الجهاز؛ جرّب تثبيت بيانات الصوت من إعدادات Android.');if(voiceCallActive)stopVoiceCall();};
  $('workMode').value=settings.mode||'general';$('workMode').addEventListener('change',()=>{settings.mode=$('workMode').value;persistSettings();updateModeHint();toast('اتغير وضع فيرا');});$('provider').addEventListener('change',()=>{if($('provider').value==='openrouter'&&$('model').value.trim()==='gpt-4o')$('model').value='openrouter/free';else if($('provider').value==='openai'&&$('model').value.trim()==='openrouter/free')$('model').value='gpt-4o';});$('defaultMode')?.addEventListener('change',()=>{if($('workMode'))$('workMode').value=$('defaultMode').value;updateModeHint();});$('newChat').onclick=newChat;$('homeBtn').onclick=()=>{closeOverlays();renderMessages();};$('settingsBtn').onclick=()=>{syncSettings();openPanel('settingsPanel');};$('settingsSide').onclick=()=>{syncSettings();openPanel('settingsPanel');};$('memoryBtn').onclick=memory;$('saveSettings').onclick=saveSettings;$('testApi').onclick=testApi;$('sendBtn').onclick=send;$('prompt').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();send();}});$('prompt').addEventListener('input',e=>{e.target.style.height='auto';e.target.style.height=Math.min(e.target.scrollHeight,130)+'px';});$('attachBtn').onclick=()=>$('fileInput').click();$('fileInput').onchange=e=>{const f=e.target.files?.[0];if(f)showAttachment(f);e.target.value='';};$('micBtn').onclick=mic;$('voiceCallBtn').onclick=toggleVoiceCall;$('voiceHero').onclick=toggleVoiceCall;$('testVoice').onclick=()=>speak('أهلًا بيك، أنا فيرا. تقدر تتكلم معايا بالعربي، وهحاول أسمعك وأرد عليك بصوت واضح.');$('toggleKey').onclick=()=>{$('apiKey').type=$('apiKey').type==='password'?'text':'password';};$('overlay').onclick=closeOverlays;document.querySelectorAll('[data-close]').forEach(b=>b.onclick=closeOverlays);document.querySelectorAll('[data-prompt]').forEach(b=>b.onclick=()=>{$('prompt').value=b.dataset.prompt;send();});$('menuBtn').onclick=()=>{$('sidebar').classList.toggle('open');$('overlay').classList.toggle('show',$('sidebar').classList.contains('open'));};$('exportChats').onclick=exportChats;$('importChatsBtn').onclick=()=>$('importChatsFile').click();$('importChatsFile').onchange=e=>{const f=e.target.files?.[0];if(f)importChats(f);e.target.value='';};
  load();
  updateVoiceHero('ready');
})();
