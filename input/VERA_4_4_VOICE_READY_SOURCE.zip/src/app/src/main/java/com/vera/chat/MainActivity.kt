package com.vera.chat

import android.app.Activity
import android.content.Intent
import android.Manifest
import android.content.pm.PackageManager
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.RecognitionListener
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.os.Build
import java.util.Locale
import android.net.Uri
import android.os.Bundle
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.JavascriptInterface
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread
import android.view.WindowManager

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null
    private val fileChooserRequestCode = 4104
    private val audioPermissionRequestCode = 4105
    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var pendingSpeechLanguage: String = "ar-EG"
    private var ttsReady: Boolean = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(6, 11, 9)
        window.navigationBarColor = android.graphics.Color.rgb(6, 11, 9)
        window.decorView.systemUiVisibility = 0
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        textToSpeech = TextToSpeech(this) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) {
                textToSpeech?.language = Locale.forLanguageTag("ar-EG")
                textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        runOnUiThread { web.evaluateJavascript("window.onVeraSpeechDone && window.onVeraSpeechDone()", null) }
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        runOnUiThread { web.evaluateJavascript("window.onVeraSpeechDone && window.onVeraSpeechDone()", null) }
                    }
                    override fun onError(utteranceId: String?, errorCode: Int) {
                        runOnUiThread { web.evaluateJavascript("window.onVeraSpeechDone && window.onVeraSpeechDone()", null) }
                    }
                })
            }
        }
        web = WebView(this)
        web.setBackgroundColor(android.graphics.Color.rgb(6, 11, 9))
        val s: WebSettings = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.allowFileAccess = false
        s.allowContentAccess = true
        s.loadsImagesAutomatically = true
        s.cacheMode = WebSettings.LOAD_DEFAULT
        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: WebChromeClient.FileChooserParams?
            ): Boolean {
                fileChooserCallback?.onReceiveValue(null)
                fileChooserCallback = filePathCallback
                return try {
                    val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                    }
                    startActivityForResult(intent, fileChooserRequestCode)
                    true
                } catch (_: Exception) {
                    fileChooserCallback?.onReceiveValue(null)
                    fileChooserCallback = null
                    false
                }
            }
        }
        web.addJavascriptInterface(NativeApi(), "VeraNative")
        setContentView(web)
        if (savedInstanceState == null) web.loadUrl("file:///android_asset/index.html") else web.restoreState(savedInstanceState)
    }
    inner class NativeApi {
        @JavascriptInterface fun openUrl(url: String) {
            runOnUiThread {
                try {
                    val uri = Uri.parse(url)
                    if (uri.scheme == "https" || uri.scheme == "http") {
                        startActivity(Intent(Intent.ACTION_VIEW, uri))
                    }
                } catch (_: Exception) { }
            }
        }
        @JavascriptInterface fun startListening(language: String) {
            pendingSpeechLanguage = if (language.startsWith("en", true)) "en-US" else "ar-EG"
            runOnUiThread {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), audioPermissionRequestCode)
                    return@runOnUiThread
                }
                beginListening()
            }
        }
        @JavascriptInterface fun stopListening() {
            runOnUiThread {
                try { speechRecognizer?.cancel() } catch (_: Exception) {}
                try { speechRecognizer?.destroy() } catch (_: Exception) {}
                speechRecognizer = null
            }
        }
        @JavascriptInterface fun speak(text: String, language: String) {
            runOnUiThread {
                val tts = textToSpeech
                if (tts == null || !ttsReady) {
                    web.evaluateJavascript("window.onVeraSpeechUnavailable && window.onVeraSpeechUnavailable()", null)
                    return@runOnUiThread
                }
                val locale = if (language.startsWith("en", true)) Locale.US else Locale.forLanguageTag("ar-EG")
                val languageStatus = tts.setLanguage(locale)
                if (languageStatus == TextToSpeech.LANG_MISSING_DATA || languageStatus == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts.setLanguage(Locale.getDefault())
                }
                tts.stop()
                val utteranceId = "vera-" + System.currentTimeMillis()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    tts.speak(text.take(4500), TextToSpeech.QUEUE_FLUSH, null, utteranceId)
                } else {
                    @Suppress("DEPRECATION")
                    tts.speak(text.take(4500), TextToSpeech.QUEUE_FLUSH, null)
                }
            }
        }
        @JavascriptInterface fun stopSpeaking() {
            runOnUiThread { try { textToSpeech?.stop() } catch (_: Exception) {} }
        }
        private fun beginListening() {
            try {
                if (!SpeechRecognizer.isRecognitionAvailable(this@MainActivity)) {
                    web.evaluateJavascript("window.onVeraSpeechError && window.onVeraSpeechError('خدمة التعرف على الكلام غير متاحة على الجهاز')", null)
                    return
                }
                try { speechRecognizer?.destroy() } catch (_: Exception) {}
                val recognizer = SpeechRecognizer.createSpeechRecognizer(this@MainActivity)
                speechRecognizer = recognizer
                recognizer.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: android.os.Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onError(error: Int) {
                        web.evaluateJavascript("window.onVeraSpeechError && window.onVeraSpeechError(${JSONObject.quote(speechErrorText(error))})", null)
                    }
                    override fun onResults(results: android.os.Bundle?) {
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val transcript = matches?.firstOrNull()?.trim().orEmpty()
                        web.evaluateJavascript("window.onVeraSpeechResult && window.onVeraSpeechResult(${JSONObject.quote(transcript)})", null)
                    }
                    override fun onPartialResults(partialResults: android.os.Bundle?) {}
                    override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
                })
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, pendingSpeechLanguage)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, pendingSpeechLanguage)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                }
                recognizer.startListening(intent)
            } catch (e: Exception) {
                web.evaluateJavascript("window.onVeraSpeechError && window.onVeraSpeechError(${JSONObject.quote(e.message ?: "تعذر بدء الميكروفون")})", null)
            }
        }
        private fun speechErrorText(error: Int): String = when (error) {
            SpeechRecognizer.ERROR_AUDIO -> "حصلت مشكلة في تسجيل الصوت"
            SpeechRecognizer.ERROR_CLIENT -> "تم إيقاف التعرف على الصوت"
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "إذن الميكروفون مرفوض"
            SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "خدمة تحويل الصوت لنص تحتاج اتصالًا أو فشلت الشبكة"
            SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "ماسمعتش كلام واضح؛ جرّب تاني"
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "الميكروفون مشغول؛ جرّب بعد لحظة"
            else -> "تعذر فهم الكلام (خطأ $error)"
        }
        @JavascriptInterface fun request(id: String, url: String, headersJson: String, body: String) {
            thread {
                var status = 0
                var response = "{}"
                try {
                    val conn = (URL(url).openConnection() as HttpURLConnection)
                    conn.requestMethod = "POST"
                    conn.connectTimeout = 25000
                    conn.readTimeout = 60000
                    conn.doOutput = true
                    val headers = JSONObject(headersJson)
                    val keys = headers.keys()
                    while (keys.hasNext()) { val k = keys.next(); conn.setRequestProperty(k, headers.getString(k)) }
                    conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                    status = conn.responseCode
                    val stream = if (status in 200..299) conn.inputStream else conn.errorStream
                    response = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: "{}"
                    conn.disconnect()
                } catch (e: Exception) {
                    response = JSONObject().put("error", JSONObject().put("message", e.message ?: "Network error")).toString()
                }
                val safe = JSONObject.quote(response)
                runOnUiThread { web.evaluateJavascript("window.onVeraNativeResult && window.onVeraNativeResult(${JSONObject.quote(id)}, $status, $safe)", null) }
            }
        }
    }
    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == fileChooserRequestCode) {
            val callback = fileChooserCallback ?: return
            val results = if (resultCode == RESULT_OK) WebChromeClient.FileChooserParams.parseResult(resultCode, data) else null
            callback.onReceiveValue(results)
            fileChooserCallback = null
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == audioPermissionRequestCode) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                beginListeningAfterPermission()
            } else {
                web.evaluateJavascript("window.onVeraSpeechError && window.onVeraSpeechError('لازم تسمح باستخدام الميكروفون لتشغيل المحادثة الصوتية')", null)
            }
        }
    }
    private fun beginListeningAfterPermission() {
        // Call through the same native helper without exposing permission internals to JavaScript.
        val native = NativeApi()
        native.startListening(pendingSpeechLanguage)
    }
    override fun onSaveInstanceState(outState: Bundle) { web.saveState(outState); super.onSaveInstanceState(outState) }
    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        // evaluateJavascript is asynchronous and returns Unit; inspect its callback result instead.
        web.evaluateJavascript("document.body.classList.contains('panel-open')") { result ->
            if (result == "true") {
                web.evaluateJavascript("closeOverlays()", null)
            } else if (web.canGoBack()) {
                web.goBack()
            } else {
                web.evaluateJavascript("closeOverlays()", null)
            }
        }
    }
    override fun onDestroy() {
        fileChooserCallback?.onReceiveValue(null)
        fileChooserCallback = null
        try { speechRecognizer?.destroy() } catch (_: Exception) {}
        speechRecognizer = null
        try { textToSpeech?.stop(); textToSpeech?.shutdown() } catch (_: Exception) {}
        textToSpeech = null
        web.destroy()
        super.onDestroy()
    }
}
